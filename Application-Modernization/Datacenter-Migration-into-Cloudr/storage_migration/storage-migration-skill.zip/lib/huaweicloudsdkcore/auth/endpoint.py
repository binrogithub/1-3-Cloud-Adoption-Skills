# coding: utf-8
"""
 Copyright 2025 Huawei Technologies Co.,Ltd.

 Licensed to the Apache Software Foundation (ASF) under one
 or more contributor license agreements.  See the NOTICE file
 distributed with this work for additional information
 regarding copyright ownership.  The ASF licenses this file
 to you under the Apache LICENSE, Version 2.0 (the
 "LICENSE"); you may not use this file except in compliance
 with the LICENSE.  You may obtain a copy of the LICENSE at

     http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing,
 software distributed under the LICENSE is distributed on an
 "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 KIND, either express or implied.  See the LICENSE for the
 specific language governing permissions and limitations
 under the LICENSE.
"""

__IAM_ENDPOINT_DICT = {
    "cn-north-2": "https://iam.cn-north-2.myhuaweicloud.com",
    "cn-north-4": "https://iam.cn-north-4.myhuaweicloud.com",
    "cn-north-1": "https://iam.cn-north-1.myhuaweicloud.com",
    "cn-east-2": "https://iam.cn-east-2.myhuaweicloud.com",
    "cn-east-3": "https://iam.cn-east-3.myhuaweicloud.com",
    "cn-south-1": "https://iam.cn-south-1.myhuaweicloud.com",
    "cn-south-2": "https://iam.cn-south-2.myhuaweicloud.com",
    "cn-southwest-2": "https://iam.cn-southwest-2.myhuaweicloud.com",
    "ap-southeast-1": "https://iam.ap-southeast-1.myhuaweicloud.com",
    "ap-southeast-2": "https://iam.ap-southeast-2.myhuaweicloud.com",
    "ap-southeast-3": "https://iam.ap-southeast-3.myhuaweicloud.com",
    "af-south-1": "https://iam.af-south-1.myhuaweicloud.com",
    "sa-brazil-1": "https://iam.sa-brazil-1.myhuaweicloud.com",
    "la-south-2": "https://iam.la-south-2.myhuaweicloud.com",
    "na-mexico-1": "https://iam.na-mexico-1.myhuaweicloud.com",
    "la-north-2": "https://iam.la-north-2.myhuaweicloud.com",
    "cn-north-9": "https://iam.cn-north-9.myhuaweicloud.com",
    "eu-west-0": "https://iam.eu-west-0.myhuaweicloud.com",
    "my-kualalumpur-1": "https://iam.my-kualalumpur-1.myhuaweicloud.com",
    "ru-moscow-1": "https://iam.ru-moscow-1.myhuaweicloud.com",
    "me-east-1": "https://iam.me-east-1.myhuaweicloud.com",
    "ap-southeast-4": "https://iam.ap-southeast-4.myhuaweicloud.com",
    "ae-ad-1": "https://iam.ae-ad-1.myhuaweicloud.com",
    "cn-east-4": "https://iam.cn-east-4.myhuaweicloud.com",
    "cn-east-5": "https://iam.cn-east-5.myhuaweicloud.com",
    "tr-west-1": "https://iam.tr-west-1.myhuaweicloud.com",
    "cn-north-12": "https://iam.cn-north-12.myhuaweicloud.com"
}
__STS_ENDPOINT_DICT = {
    "cn-north-4": "https://sts.cn-north-4.myhuaweicloud.com",
    "cn-south-1": "https://sts.cn-south-1.myhuaweicloud.com",
    "cn-east-3": "https://sts.cn-east-3.myhuaweicloud.com",
    "cn-southwest-2": "https://sts.cn-southwest-2.myhuaweicloud.com",
    "ap-southeast-1": "https://sts.ap-southeast-1.myhuaweicloud.com",
    "ap-southeast-3": "https://sts.ap-southeast-3.myhuaweicloud.com",
    "ap-southeast-2": "https://sts.ap-southeast-2.myhuaweicloud.com",
    "sa-brazil-1": "https://sts.sa-brazil-1.myhuaweicloud.com",
    "la-south-2": "https://sts.la-south-2.myhuaweicloud.com",
    "af-south-1": "https://sts.af-south-1.myhuaweicloud.com",
    "ap-southeast-4": "https://sts.ap-southeast-4.myhuaweicloud.com",
    "tr-west-1": "https://sts.tr-west-1.myhuaweicloud.com"
}


def get_iam_endpoint_by_id(region_id, default=None):
    return __IAM_ENDPOINT_DICT.get(region_id, default)


def get_sts_endpoint_by_id(region_id, default=None):
    return __STS_ENDPOINT_DICT.get(region_id, default)
