import warnings
import sys
import os
import json
import argparse

warnings.filterwarnings('ignore')

script_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.dirname(script_dir)
if project_root not in sys.path:
    sys.path.insert(0, project_root)
if os.path.join(project_root, 'lib') not in sys.path:
    sys.path.insert(0, os.path.join(project_root, 'lib'))

mgc_edge_home = os.environ.get('MgC_EDGE_HOME', r'C:\RDA')
relay_path = os.path.join(mgc_edge_home, 'tools', 'plugins', 'relayagent', 'plugins', 'relayagent', 'bin', 'packages', 'relay-core', 'src')
if str(relay_path) not in sys.path:
    sys.path.insert(0, str(relay_path))

from relay_core.infrastructure.external.rda_client.client import RdaClient
from list_credentials import CredentialService

def create_task(api_cred_name, src_cred_name, dst_cred_name, dst_region, src_cloud_type,
                src_region, src_bucket, prefixes, dst_bucket, save_prefix,
                enable_failed_object_recording, enable_metadata_migration, overwrite_mode):
    from lib.huaweicloudsdkcore.auth.credentials import BasicCredentials
    from lib.huaweicloudsdkcore.http.http_config import HttpConfig
    from lib.huaweicloudsdkoms.v2 import OmsClient
    from lib.huaweicloudsdkoms.v2.region.oms_region import OmsRegion
    from lib.huaweicloudsdkoms.v2.model.create_task_req import CreateTaskReq
    from lib.huaweicloudsdkoms.v2.model.create_task_request import CreateTaskRequest
    from lib.huaweicloudsdkoms.v2.model.src_node_req import SrcNodeReq
    from lib.huaweicloudsdkoms.v2.model.dst_node_req import DstNodeReq

    rda_client = RdaClient()
    cred_service = CredentialService(rda_client)

    api_ak_sk = cred_service.get_ak_sk_by_name(api_cred_name)
    if 'error' in api_ak_sk:
        raise ValueError(f"获取API凭证失败: {api_ak_sk['error']}")
    api_ak = api_ak_sk.get('ak')
    api_sk = api_ak_sk.get('sk')

    src_ak_sk = cred_service.get_ak_sk_by_name(src_cred_name)
    if 'error' in src_ak_sk:
        raise ValueError(f"获取源端凭证失败: {src_ak_sk['error']}")
    src_ak = src_ak_sk.get('ak')
    src_sk = src_ak_sk.get('sk')

    dst_ak_sk = cred_service.get_ak_sk_by_name(dst_cred_name)
    if 'error' in dst_ak_sk:
        raise ValueError(f"获取目的端凭证失败: {dst_ak_sk['error']}")
    dst_ak = dst_ak_sk.get('ak')
    dst_sk = dst_ak_sk.get('sk')

    http_config = HttpConfig.get_default_config()
    http_config.ignore_ssl_verification = True
    credentials = BasicCredentials(api_ak, api_sk)

    client = (OmsClient.new_builder()
              .with_credentials(credentials)
              .with_region(OmsRegion.value_of(dst_region))
              .with_endpoint(OmsRegion.value_of(dst_region).endpoint)
              .with_http_config(http_config)
              .build())

    src_node = SrcNodeReq(
        cloud_type=src_cloud_type,
        region=src_region,
        bucket=src_bucket,
        ak=src_ak,
        sk=src_sk,
        object_key=prefixes if isinstance(prefixes, list) else [prefixes]
    )

    if save_prefix:
        dst_node = DstNodeReq(
            region=dst_region,
            bucket=dst_bucket,
            ak=dst_ak,
            sk=dst_sk,
            save_prefix=save_prefix if save_prefix.lower() != 'none' else None
        )
    else:
        dst_node = DstNodeReq(
            region=dst_region,
            bucket=dst_bucket,
            ak=dst_ak,
            sk=dst_sk
        )

    body = CreateTaskReq(
        task_type='prefix',
        src_node=src_node,
        dst_node=dst_node,
        enable_failed_object_recording=enable_failed_object_recording,
        enable_metadata_migration=enable_metadata_migration,
        object_overwrite_mode=overwrite_mode
    )

    request = CreateTaskRequest(body=body)

    try:
        response = client.create_task(request)
        result = {
            'success': True,
            'task_id': response.id,
            'task_name': response.task_name
        }
        print(json.dumps(result, ensure_ascii=False))
        return result
    except Exception as e:
        result = {
            'success': False,
            'error': str(e),
            'error_code': getattr(e, 'error_code', None),
            'error_msg': getattr(e, 'error_msg', None),
            'status_code': getattr(e, 'status_code', None)
        }
        print(json.dumps(result, ensure_ascii=False))
        return result

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='创建OMS存储迁移任务')
    parser.add_argument('--api-cred-name', required=True, help='API凭证名称')
    parser.add_argument('--src-cred-name', required=True, help='源端凭证名称')
    parser.add_argument('--dst-cred-name', required=True, help='目的端凭证名称')
    parser.add_argument('--dst-region', required=True, help='目的端Region')
    parser.add_argument('--src-cloud-type', required=True, help='源端云服务商代码')
    parser.add_argument('--src-region', required=True, help='源端Region')
    parser.add_argument('--src-bucket', required=True, help='源端桶名称')
    parser.add_argument('--prefixes', required=True, help='迁移前缀列表，逗号分隔')
    parser.add_argument('--dst-bucket', required=True, help='目的端桶名称')
    parser.add_argument('--save-prefix', default=None, help='保存前缀（可选，不传表示不启用）')
    parser.add_argument('--enable-failed-object-recording', type=lambda x: x.lower() == 'true', default=True, help='是否启用失败对象记录（默认True）')
    parser.add_argument('--enable-metadata-migration', type=lambda x: x.lower() == 'true', default=False, help='是否启用元数据迁移（默认False）')
    parser.add_argument('--overwrite-mode', default='SIZE_LAST_MODIFIED_COMPARISON_OVERWRITE', help='同名对象覆盖方式')

    args = parser.parse_args()

    prefixes = [p.strip() for p in args.prefixes.split(',')]

    create_task(
        args.api_cred_name, args.src_cred_name, args.dst_cred_name,
        args.dst_region, args.src_cloud_type, args.src_region, args.src_bucket,
        prefixes, args.dst_bucket, args.save_prefix,
        args.enable_failed_object_recording, args.enable_metadata_migration, args.overwrite_mode
    )
