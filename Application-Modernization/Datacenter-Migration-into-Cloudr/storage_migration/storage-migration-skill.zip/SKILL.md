---
name: storage-migration-skill
description: |
  存储迁移任务创建Skill。通过多轮问答引导用户完成华为云OMS存储迁移任务配置，无需记忆API参数。

  【意图识别触发规则】
  当用户表达以下意图时，本skill将被触发：

  【主场景 - 创建迁移任务】
  - "创建存储迁移任务"、"创建迁移任务"、"新建迁移任务"
  - "帮我创建迁移"、"创建一个迁移任务"
  - "迁移存储"、"迁移数据"、"迁移文件"
  - "对象存储迁移"、"OBS迁移"、"S3迁移"
  - "oms迁移"、"oms任务"、"oms创建任务"

  【主场景 - 迁移数据到华为云】
  - "从AWS迁移到华为云"、"从阿里云迁移到华为云"
  - "从腾讯云迁移"、"从Azure迁移"
  - "把某地的数据迁移到华为云"、"数据上云"
  - "跨云迁移"、"多云迁移"

  【主场景 - 前缀迁移】
  - "前缀迁移"、"按前缀迁移"、"迁移指定前缀"
  - "迁移某个目录下的文件"、"迁移prefix开头的数据"
  - "只迁移特定前缀"、"迁移data/目录"

  【主场景 - 桶间迁移】
  - "桶间迁移"、"bucket之间迁移"
  - "同一个云的不同桶之间迁移"

  【辅助场景 - 迁移任务管理】
  - "查看迁移任务"、"我的迁移任务"
  - "迁移任务状态"、"迁移进度"
  - "查看任务配置信息"、"查看配置"

  【排除场景 - 不触发】
  - 用户只是询问迁移原理、费用、限制等概念性问题（应直接回答，不触发本skill）
  - 用户明确表示"只是问问"或"先了解一下"（应先回答问题，确认需要创建任务后再触发）

  【响应场景 - 配置查询】
  - 当用户询问"查看任务配置"、"查看配置"、"配置信息"、"我填了哪些信息"时，AI必须展示【已收集的任务数据】表格

  【支持的迁移模式】
  - 前缀迁移（prefix）：基于前缀匹配批量迁移对象

  【支持的云服务商】
  - AWS、Azure、阿里云、腾讯云、华为云、青云、金山云、百度云、七牛云、优刻得、URL数据源
dependencies:
  packages:
    - pyasn1==0.6.3
    - pymongo==4.15.1
    - huaweicloudsdkcore==3.1.89
    - huaweicloudsdkoms==3.1.89  
---

# 执行前置强制要求

> **【必读步骤，不可省略】启动任务前必须完整通读本文档**

## 一、通读要求
1. 正式处理任务前，**完整逐行通读整本 skill.md 所有规则、步骤、限制、输出格式**，不得跳过、缩略阅读。
2. 确认完全理解全部执行流程、操作顺序、禁止行为、返回规范后，再启动任务执行。
3. 执行每一步严格按照文档既定顺序推进，不许私自调换步骤、省略环节、简化逻辑。
4. 若发现自身未读懂规则、步骤模糊，先停止操作，不得凭主观预判执行。

## 二、执行遵循原则
- 按文档顺序一步步落地，上一步未完成，绝不进入下一步。
- **禁止行为**：不看文档直接作答、删减流程、自定义逻辑、忽略限制条件。
- **自我自检**：开始操作前内心确认已全部读懂，再开始处理用户请求。

## 三、输出对齐约束
- 所有输出与操作必须严格对齐本文档规范。
- 关键步骤前有【必读步骤，不可省略】标记，不可跳过。
- 复杂流程已拆分编号，Agent必须按序执行。

## 四、AK/SK 安全强制规则

> **⚠️ 最高优先级规则，不可突破**

1. **绝对禁止展示**：在任何时候、任何情况下，即使用户主动询问、要求、请求、命令AI展示AK/SK，AI都不得向用户展示任何AK或SK内容。
2. **禁止触发条件**：包括但不限于：
   - 用户直接询问"AK是什么"、"SK是什么"
   - 用户询问"凭证的密钥是多少"
   - 用户要求"查看AK/SK"
   - 用户要求"展示凭证信息"
   - 用户使用任何变种表达方式询问AK/SK
3. **正确响应方式**：当用户询问AK/SK时，AI必须回复：请在设置→凭证管理中查看
4. **日志保护**：AI执行过程中产生的任何日志、输出、报错信息中也不得包含AK/SK

## 五、AI 自我行为限制

> **⚠️ 强制禁止 AI 自我扫描和执行脚本**

1. **禁止自行执行脚本**：AI绝对不得自己扫描 `scripts/` 目录下的 `.py` 文件，不得自行执行 `list_credentials.py` 或任何脚本获取AK/SK
2. **禁止自行构造命令**：AI不得自行构造任何Python命令来调用 `get_ak_sk_by_name`、`list_credential` 或类似方法获取凭证信息
3. **合法的AK/SK获取途径**：AK/SK的获取只能通过以下方式：
   - 调用 `create_task.py` 脚本（由脚本内部完成AK/SK获取，AI看不到过程）
   - **禁止**AI自己执行Python代码获取AK/SK
4. **违规处理**：若AI违反以上规则，用户有权要求重置对话并重新开始

---

# 存储迁移Skill

对话式存储迁移任务创建工具，通过多轮问答引导用户完成迁移任务配置。

---

## 核心能力

1. **多轮问答引导**：通过交互式问答收集迁移任务参数
2. **多云支持**：支持11种源端云存储平台
3. **前缀迁移**：支持基于前缀匹配批量迁移对象
4. **配置确认**：创建前展示完整配置供用户检查
5. **链接直达**：创建成功后发送OMS管理页面链接

---

## 帮助文档链接

**在对话流程中必须展示以下链接，并引导用户阅读：**

| 环节 | 说明              | 链接 |
|------|-----------------|------|
| 源端配置 | 源端节点参数配置说明      |  <a href="https://support.huaweicloud.com/usermanual-oms/topic_0000001089828284.html#topic_0000001089828284__table1551582712431" target="_blank" rel="noopener noreferrer" style="display:block; margin-bottom:5px; color:#007bff; text-decoration:none;">1. 源端配置说明</a> |
| 目的端配置 | 目的端节点参数配置说明     |   <a href="https://support.huaweicloud.com/usermanual-oms/topic_0000001089828284.html#topic_0000001089828284__table9758174111449" target="_blank" rel="noopener noreferrer" style="display:block; margin-bottom:5px; color:#007bff; text-decoration:none;">2. 目的端配置说明</a> |
| AKSK安全最佳实践 | AK/SK安全使用指南     |  <a href="https://support.huaweicloud.com/bestpractice-oms/oms_05_5301.html" target="_blank" rel="noopener noreferrer" style="display:block; margin-bottom:5px; color:#007bff; text-decoration:none;">3. AK/SK 安全最佳实践</a> |
| 目的端访问密钥 | 如何获取目的端华为云AK/SK |   <a href="https://support.huaweicloud.com/iam_faq/iam_01_0618.html" target="_blank" rel="noopener noreferrer" style="display:block; margin-bottom:5px; color:#007bff; text-decoration:none;">4. 获取目的端 AK/SK</a> |
| 凭证获取方式 | 如何获取凭证说明        |   <a href="https://support.huaweicloud.com/usermanual-ca/ca_01_0003.html" target="_blank" rel="noopener noreferrer" style="display:block; margin-bottom:5px; color:#007bff; text-decoration:none;">5. 凭证获取方式</a> |

---

## 执行前确认

> **⚠️ 重要：完成以下确认后，才进入执行步骤**
 
**调用 `update_context_memory` 函数，将【已收集的任务数据】置空，key为storage_migration_task**
内容如下
```
{
  "section": "Conventions",
  "content": "storage_migration_task={\"step_0_user_check\":false,\"step_1_credentials_completed\":false,\"step_2_source_completed\":false,\"step_3_destination_completed\":false,\"step_4_options_completed\":false,\"step_5_confirm_completed\":false,\"api_cred_name\":\"\",\"src_cred_name\":\"\",\"dst_cred_name\":\"\",\"src_cloud_type\":\"\",\"src_region\":\"\",\"src_bucket\":\"\",\"prefixes\":[],\"dst_region\":\"\",\"dst_bucket\":\"\",\"save_prefix\":\"\",\"enable_failed_object_recording\":true,\"enable_metadata_migration\":false,\"overwrite_mode\":\"SIZE_LAST_MODIFIED_COMPARISON_OVERWRITE\"}"
}
```

### 🔴 执行前必须确认

**在开始执行前，Agent必须先向用户展示完整的执行流程概览：**

```
【存储迁移任务创建 - 执行流程】

共5个步骤，将按顺序执行：

步骤1：凭证配置（一次性获取API、源端、目的端凭证）
  ↓
步骤2：配置源端信息（云服务商、Region、桶、前缀）
  ↓
步骤3：收集目的端信息（Region、桶、保存前缀）
  ↓
步骤4：配置任务选项（失败记录、元数据、覆盖方式）
  ↓
步骤5：配置确认与创建任务

请回复"确认"开始执行。
```

> **完整规则请参阅：rule.md**

当用户确认后，本步骤完成，设置 `step_0_user_check = True`，等待用户进入下一步。

>必须调用`update_context_memory`方法进行更新
```
update_context_memory {
  "section": "Conventions",
  "content": "storage_migration_task={
    "step_0_user_check": True,
    ...（其他字段保持原值）
}
}
```

**数据记录表（必须实时维护，贯穿整个对话）：**
```
【已收集的任务数据】
- API凭证名称：待填写
- 源端凭证名称：待填写
- 目的端凭证名称：待填写
- 源端云服务商：待填写
- 源端Region：待填写
- 源端桶名称：待填写
- 源端前缀：待填写
- 目的端Region：待填写
- 目的端桶名称：待填写
- 目的端保存前缀：待填写（默认不启用）
- 失败对象记录：待选择（默认启用）
- 元数据迁移：待选择（默认禁用）
- 同名对象覆盖方式：待选择（默认SIZE_LAST_MODIFIED_COMPARISON_OVERWRITE）
```

**⚠️ 重要：Agent 必须始终维护这个数据记录表**
- 这是 Agent 唯一的数据来源
- **每次回复用户前，必须先从对话记忆中查询【已收集的任务数据】，确认哪些字段已填写**
- 如果发现某字段已填写，必须向用户展示"已确认"标记，不能要求用户重新输入
- 如果某字段为空，才询问用户
- **即使 Agent 忘记之前的输入，也必须能够从对话记忆中恢复**，而不是让用户重新输入

**数据复用规则：**
- 后续步骤必须使用已填写的值
- 禁止要求用户重新填写已记录的数据
- 如果某个字段已填写，必须使用已填写的值继续执行
- 如用户需要修改已填写的数据，必须明确询问要修改哪一项

---

## 对话和执行步骤

**重要提示：每次用户输入的时候都需要查询当前步骤和数据**
Agent首先调用以下指令
```
search_memory(query="storage_migration_task")
```
**然后所有依据都从search_memory来判断**

### 第一步：凭证配置

**Agent按以下顺序执行：**

#### 1.1 展示提示信息

告诉用户：**在继续之前，请先在设置 → 凭证管理中保存您的云凭证。**

展示凭证获取方式链接。

#### 1.2 执行命令获取可用凭证列表

Agent执行以下命令获取已保存的凭证列表：
```
$ cd "%SKILL_PATH%"; python -c "import sys; sys.path.insert(0, 'scripts'); from list_credentials import CredentialService; import os; mgc_edge_home = os.environ.get('MgC_EDGE_HOME', r'C:\RDA'); relay_path = os.path.join(mgc_edge_home, 'tools', 'plugins', 'relayagent', 'plugins', 'relayagent', 'bin', 'packages', 'relay-core', 'src'); sys.path.insert(0, relay_path); from relay_core.infrastructure.external.rda_client.client import RdaClient; client = RdaClient(); service = CredentialService(client); print('可用凭证列表:', service.get_all_names())"
```

#### 1.3 展示实际获取到的凭证列表

Agent必须展示从命令输出中获取的实际列表，格式如下：
```
可用凭证列表: ['credential_1', 'credential_2', 'my_ak_sk']
```

#### 1.4 让用户一次性选择三个凭证

展示列表后，明确询问用户：
**请一次性选择以下三个凭证（直接回复凭证名称，用逗号分隔）：**

1. **API凭证**（用于调用OMS API）
2. **源端凭证**（用于访问源端桶）
3. **目的端凭证**（用于访问目的端桶）

**格式示例：** `my_ak_sk,src_credential,dst_credential`

本次迁移任务的Region将与目的端Region保持一致，请确保选择的凭证与您的目的端桶所在区域匹配。

用户输入后，Agent首先调用以下指令，在进行推理时，必须带上记忆storage_migration_task

```
search_memory(query="storage_migration_task")
```
1. 检查 `step_0_user_check` 是否为 `true`
2. 如果 `step_0_user_check = false`，**立即报错并终止**
3. 如果 `step_1_credentials_completed = true`，展示已完成状态并跳过
4. 如果 `step_1_credentials_completed = false` 且前置步骤已完成，继续执行步骤2

**检查数据记录表，如果API凭证名称、源端凭证名称、目的端凭证名称已填写，向用户确认后跳过本步；如果为空才继续执行。**

#### 1.5 验证三个凭证是否都可获取

执行以下命令验证凭证有效性（只检查凭证是否在列表中，不获取AK/SK）：
```
$ cd "%SKILL_PATH%"; python -c "import sys; sys.path.insert(0, 'scripts'); from list_credentials import CredentialService; import os; mgc_edge_home = os.environ.get('MgC_EDGE_HOME', 'C:\\RDA'); relay_path = os.path.join(mgc_edge_home, 'tools', 'plugins', 'relayagent', 'plugins', 'relayagent', 'bin', 'packages', 'relay-core', 'src'); sys.path.insert(0, relay_path); from relay_core.infrastructure.external.rda_client.client import RdaClient; client = RdaClient(); service = CredentialService(client); creds = '用户输入的三个凭证名称'; names = [n.strip() for n in creds.split(',')]; all_names = service.get_all_names(); errors = [n for n in names if n not in all_names]; print('验证结果: 全部成功' if not errors else f'以下凭证获取失败: {errors}')"
```

#### 1.6 更新数据记录表

**调用 `update_context_memory ` 函数保存更新的【已收集的任务数据】key=storage_migration_task**
当用户确认后，本步骤完成，设置 `step_1_credentials_completed = True`，等待用户进入下一步。

>必须调用`update_context_memory`方法进行更新
```
update_context_memory {
  "section": "Conventions",
  "content": "storage_migration_task={
    "step_1_credentials_completed": True,
    "api_cred_name": "{api_cred_name}",
    "src_cred_name": "{src_cred_name}",
    "dst_cred_name": "{dst_cred_name}",
    ...（其他字段保持原值）
}
}
```
验证通过后，将三个凭证名称填入数据记录表，然后**向用户展示完整的数据记录表**
```
【已收集的任务数据】
- API凭证名称：{api_cred_name}
- 源端凭证名称：{src_cred_name}
- 目的端凭证名称：{dst_cred_name}
- ...（其他字段保持原值，待后续步骤填写）
```
---

### 第二步：配置源端信息

**Agent按以下顺序执行：**

#### 2.1 展示可选云服务商列表

**⚠️ 提示：准确无误的展示下列数据，严禁私自修改**

| 云服务商代码 | 显示名称 |
|--------------|----------|
| AWS | 亚马逊云 (AWS) |
| Azure | 微软云 (Azure) |
| Aliyun | 阿里云 (Aliyun) |
| Tencent | 腾讯云 (Tencent) |
| HuaweiCloud | 华为云 (HuaweiCloud) |
| QingCloud | 青云 (QingCloud) |
| KingsoftCloud | 金山云 (KingsoftCloud) |
| Baidu | 百度云 (Baidu) |
| Qiniu | 七牛云 (Qiniu) |
| UCloud | 优刻得 (UCloud) |

#### 2.2 展示帮助文档链接

展示源端配置帮助文档链接。

#### 2.3 收集源端信息

让用户输入云服务商代码、Region、桶名称和前缀，格式：`云服务商代码;RegionID;桶名称;前缀列表`（多个前缀用逗号分隔）

**示例：** `AWS;us-east-1;my-bucket;prefix/,backup/` 或 `Aliyun;cn-hangzhou;src-bucket;data/`

常见Region：`cn-north-4`（华北-北京四）、`cn-east-3`（华东-上海一）、`cn-south-1`（华南-广州）、`ap-southeast-1`（中国香港）、`us-east-1`（AWS美东）、`ap-southeast-1`（阿里云新加坡）

**⚠️ 重要：云服务商代码映射规则**
- 用户输入"华为云"、"OBS"、"HuaweiCloud" → 必须转换为 `HuaweiCloud`
- 用户输入"阿里云"、"Aliyun" → 必须转换为 `Aliyun`
- 用户输入"亚马逊"、"AWS" → 必须转换为 `AWS`
- 用户输入"腾讯云"、"Tencent" → 必须转换为 `Tencent`
- 其他云服务商同理，**最终填入数据记录表的必须是代码格式**


用户输入后，Agent首先调用以下指令，在进行推理时，必须带上记忆storage_migration_task
**调用 `search_memory` 获取当前已收集的数据：**
Agent首先调用以下指令
```
search_memory(query="storage_migration_task")
```
1. 检查 `step_1_credentials_completed` 是否为 `true`
2. 如果 `step_1_credentials_completed = false`，**立即报错并终止**
3. 如果 `step_2_source_completed = true`，展示已完成状态并跳过
4. 如果 `step_2_source_completed = false` 且前置步骤已完成，继续执行第二步：配置源端信息

根据结果判断哪些字段已填写，如果源端云服务商、Region、桶名称、前缀已填写，向用户确认后跳过本步；如果为空才继续执行。

#### 2.4 更新memory并确认

将云服务商（**必须是代码格式**）、Region、桶名称、前缀填入数据记录表，**调用 `update_context_memory ` 函数保存更新的【已收集的任务数据】,key为storage_migration_task**，
>必须调用`update_context_memory`方法进行更新
```
update_context_memory {
  "section": "Conventions",
  "content": "storage_migration_task={
    "step_2_source_completed": True,
    "src_cloud_type": "{src_cloud_type}",
    "src_region": "{src_region}",
    "src_bucket": "{src_bucket}",
    "prefixes": [{prefix1}, {prefix2}],
    ...（其他字段保持原值）
}
}
```
然后**向用户展示完整的数据记录表**
```

【已收集的任务数据】
- API凭证名称：{api_cred_name}
- 源端凭证名称：{src_cred_name}
- 目的端凭证名称：{dst_cred_name}
- 源端云服务商：{src_cloud_type}（必须是HuaweiCloud/Aliyun/AWS等代码）
- 源端Region：{src_region}
- 源端桶名称：{src_bucket}
- 源端前缀：{prefixes}
- ...（其他字段保持原值）
```
---

### 第三步：收集目的端信息

**Agent按以下顺序执行：**

#### 3.1 收集目的端Region、桶名称和保存前缀

告诉用户：请输入目的端Region、桶名称和保存前缀（可选），格式：`RegionID;桶名称;保存前缀`（不填保存前缀表示不启用）

展示目的端配置帮助文档链接。

**示例：** `cn-north-4;oms-north-4` 或 `cn-east-3;my-bucket;backup/`

展示常见Region：`cn-north-4`（华北-北京四）、`cn-east-3`（华东-上海一）、`cn-south-1`（华南-广州）

**只展示，不用下列规则校验
```
⚠️ 保存前缀校验规则（不填表示不启用）：**
- 不能以英文句号（.）开头或结尾
- 不能以斜杠（/）开头
- 不能包含以下字符：\:*?"<>|
- 不能包含两个以上相邻的斜杠（/）
```
使用正则式"^(?!\.)(?!^/)(?!.*\/\/)(?!.*\/$)[^\\:*?"<>|]+(?<!\.)$" 校验保存前缀

用户输入后，Agent首先调用以下指令，在进行推理时，必须带上记忆storage_migration_task
**调用 `search_memory` 获取当前已收集的数据：**
Agent首先调用以下指令
```
search_memory(query="storage_migration_task")
```
获取当前已收集的数据：
1. 检查 `step_1_credentials_completed` 是否为 `true`
2. 检查 `step_2_source_completed` 是否为 `true`
3. 如果 `step_3_destination_completed = true`，展示已完成状态并跳过
4. 如果 `step_3_destination_completed = false` 且前置步骤已完成，继续执行第三步：收集目的端信息

根据结果判断哪些字段已填写，如果目的端Region、桶名称已填写，向用户确认后跳过本步；如果为空才继续执行。

#### 3.2 更新memory

将目的端Region、桶名称、保存前缀填入数据记录表，**调用 `update_context_memory` 函数保存更新的【已收集的任务数据】,key为storage_migration_task**，

设置 `step_3_destination_completed = True`

>必须调用`update_context_memory`方法进行更新

```
update_context_memory {
  "section": "Conventions",
  "content": "storage_migration_task={
    "step_3_destination_completed": True,
    "dst_region": "{dst_region}",
    "dst_bucket": "{dst_bucket}",
    "save_prefix": "{save_prefix}",
    ...（其他字段保持原值）
}}
```

然后**向用户展示完整的数据记录表**
```
【已收集的任务数据】
- API凭证名称：{api_cred_name}
- 源端凭证名称：{src_cred_name}
- 目的端凭证名称：{dst_cred_name}
- 源端云服务商：{src_cloud_type}
- 源端Region：{src_region}
- 源端桶名称：{src_bucket}
- 源端前缀：{prefixes}
- 目的端Region：{dst_region}
- 目的端桶名称：{dst_bucket}
- 目的端保存前缀：{dst_save_prefix}
- ...（其他字段保持原值）
```
---

### 第四步：配置任务选项

**Agent按以下顺序执行：**

#### 4.1 配置任务选项

询问用户，请使用以下格式回复：`是否启用失败记录;是否启用元数据迁移;覆盖方式代码`

**选项说明：**
- 失败对象记录：默认启用（enable_failed_object_recording=True）
- 元数据迁移：默认禁用（enable_metadata_migration=False）

**同名对象覆盖方式（必选）：**

| 同名对象覆盖方式 | 显示名称 |
|--------------|----------|
| CRC64_COMPARISON_OVERWRITE | CRC64对比覆盖 |
| NO_OVERWRITE | 不覆盖 |
| SIZE_LAST_MODIFIED_COMPARISON_OVERWRITE | 大小/最后修改时间对比覆盖 |
| FULL_OVERWRITE | 全覆盖 |

**⚠️ 覆盖方式校验规则：**
- 只能是 `CRC64_COMPARISON_OVERWRITE`、`NO_OVERWRITE`、`SIZE_LAST_MODIFIED_COMPARISON_OVERWRITE`、`FULL_OVERWRITE` 之一
- 必须与表格中的代码完全一致

**示例回复：** `是;否;SIZE_LAST_MODIFIED_COMPARISON_OVERWRITE`

明确询问用户：**请配置任务选项（格式：失败记录;元数据;覆盖方式）：**

用户输入后，Agent首先调用以下指令，在进行推理时，必须带上记忆storage_migration_task
**【记忆查询】** 调用 `search_memory` 函数获取{"query": "storage_migration_task"}，
Agent首先调用以下指令
```
search_memory(query="storage_migration_task")
```
 获取当前已收集的数据：
1. 检查所有前置步骤的 `completed` 标志
2. 如果任一前置步骤为 `false`，**立即报错并终止**
3. 如果 `step_4_options_completed = true`，展示已完成状态并跳过
4. 如果 `step_4_options_completed = false` 且前置步骤已完成，继续执行步骤4

根据结果判断哪些字段已填写，如果失败对象记录、元数据迁移、同名对象覆盖方式已填写，向用户确认后跳过本步；如果为空才继续执行。

#### 4.2 更新数据记录表

将失败对象记录、元数据迁移、同名对象覆盖方式填入数据记录表

**调用 `update_context_memory` 函数保存更新的【已收集的任务数据】，key为storage_migration_task**
设置 `step_4_options_completed = True`
>必须调用`update_context_memory`方法进行更新
```
update_context_memory {
  "section": "Conventions",
  "content": "storage_migration_task={
    "step_4_options_completed": True,
    "enable_failed_object_recording": {True/False},
    "enable_metadata_migration": {True/False},
    "overwrite_mode": "{overwrite_mode}",
    ...（其他字段保持原值）
}}
```
---

### 第五步：配置确认与创建任务

#### 5.1 展示完整配置清单
```
========== 迁移任务配置确认 ==========

【凭证配置】
  API凭证名称：{api_cred_name}（AK/SK自动获取）
  源端凭证名称：{src_cred_name}（AK/SK自动获取）
  目的端凭证名称：{dst_cred_name}（AK/SK自动获取）

【源端配置】
  云服务商：{src_cloud_type}（代码格式，如HuaweiCloud/Aliyun/AWS）
  Region：{src_region}
  桶名称：{src_bucket}
  前缀列表：{prefixes}

【目的端配置】
  Region：{dst_region}
  桶名称：{dst_bucket}
  保存前缀：{save_prefix/不启用}

【任务选项】
  失败对象记录：启用
  任务类型：前缀迁移（prefix）
  元数据迁移方式：禁用
  同名对象覆盖方式：{overwrite_mode}

======================================
```

**请用户确认配置是否正确，输入"确认"继续或"修改"进行更改。**

用户输入后，Agent首先调用以下指令，在进行推理时，必须带上记忆storage_migration_task
**【记忆查询】** 调用 `search_memory` 函数获取{"query": "storage_migration_task"}，
Agent首先调用以下指令
```
search_memory(query="storage_migration_task")
```
1. 检查所有前置步骤的 `completed` 标志
2. 如果任一前置步骤为 `false`，**立即报错并终止**
3. 如果 `step_5_confirm_completed = true`，展示已完成状态（任务已创建）
4. 如果所有前置步骤已完成且 `step_5_confirm_completed = false`，继续执行步骤5

#### 5.2 用户确认后执行创建命令
  --save-prefix "保存前缀（不填或空表示不启用）" ^ 仅在值不为""时才带入下面代码；例如，--save-prefix ""时，删除下面的--save-prefix

```powershell
$ cd %SKILL_PATH%; $env:MgC_EDGE_HOME = 'C:\RDA'; python scripts/create_task.py ^
  --api-cred-name "API凭证名称" ^
  --src-cred-name "源端凭证名称" ^
  --dst-cred-name "目的端凭证名称" ^
  --dst-region "目的端Region" ^
  --src-cloud-type "源端云服务商代码" ^
  --src-region "源端Region" ^
  --src-bucket "源端桶名称" ^
  --prefixes "前缀1,前缀2" ^
  --dst-bucket "目的端桶名称" ^
  --save-prefix "保存前缀（不填或空表示不启用）" ^
  --enable-failed-object-recording "是否启用失败对象记录" ^
  --enable-metadata-migration "是否启用元数据迁移" ^
  --overwrite-mode "同名对象覆盖方式"
```

**参数说明：**

| 参数 | 说明 |
|------|------|
| `--api-cred-name` | API凭证名称 |
| `--src-cred-name` | 源端凭证名称 |
| `--dst-cred-name` | 目的端凭证名称 |
| `--dst-region` | 目的端Region ID |
| `--src-cloud-type` | 源端云服务商代码（必须是HuaweiCloud/Aliyun/AWS/Tencent等） |
| `--src-region` | 源端Region ID |
| `--src-bucket` | 源端桶名称 |
| `--prefixes` | 迁移前缀，逗号分隔 |
| `--dst-bucket` | 目的端桶名称 |
| `--save-prefix` | 保存前缀（可选） |
| `--enable-failed-object-recording` | 是否启用失败对象记录（默认True） |
| `--enable-metadata-migration` | 是否启用元数据迁移（默认False） |
| `--overwrite-mode` | 覆盖策略 |

**返回结果：**
- 成功：`{"success": true, "task_id": "xxx", "task_name": "xxx"}`
- 失败：`{"success": false, "error": "...", "error_code": "..."}`

**创建任务失败处理：**
当返回 error_code 为 `OMS.0064` 或错误信息包含"参数错误"、"invalid"等关键词时：
1. **重新展示【已收集的任务数据】表格**，告知用户任务创建失败
2. **自检输入的参数**：对照参数说明表检查每个参数是否符合格式要求
3. **给出建议**：不要自己修复，而是告诉用户可能的问题所在（如Region格式、云服务商代码、桶名称格式等）
4. **等待用户确认**：让用户决定如何修改
当python脚本执行失败时，给出执行脚本，让用户复制到对话框重新执行；

**示例提示语：**
```
❌ 任务创建失败（OMS.0064 参数错误）

【已收集的任务数据】
- API凭证名称：xxx
- 源端凭证名称：xxx
- 目的端凭证名称：xxx
- 源端云服务商：xxx
- 源端Region：xxx
- 源端桶名称：xxx
- 源端前缀：xxx
- 目的端Region：xxx
- 目的端桶名称：xxx
- 目的端保存前缀：xxx（不启用）
- 失败对象记录：xxx
- 元数据迁移：xxx
- 同名对象覆盖方式：xxx

⚠️ 请检查以下参数是否符合要求：
- Region：必须是支持的Region ID（如 cn-north-4）
- 云服务商：必须是代码（如 HuaweiCloud、Aliyun、AWS）
- 桶名称：必须是字母或数字开头和结尾，中间可包含.或-
- 前缀：不能为空，多个前缀用逗号分隔

请告诉我需要修改哪一项？
```

**创建成功后：**
1. 展示任务创建成功信息
2. **必须展示OMS管理页面链接**
3. **调用 `update_context_memory` 函数，将【已收集的任务数据】置空，key为storage_migration_task**
内容如下
```
{
  "section": "Conventions",
  "content": "storage_migration_task={\"step_0_user_check\":false,\"step_1_credentials_completed\":false,\"step_2_source_completed\":false,\"step_3_destination_completed\":false,\"step_4_options_completed\":false,\"step_5_confirm_completed\":false,\"api_cred_name\":\"\",\"src_cred_name\":\"\",\"dst_cred_name\":\"\",\"src_cloud_type\":\"\",\"src_region\":\"\",\"src_bucket\":\"\",\"prefixes\":[],\"dst_region\":\"\",\"dst_bucket\":\"\",\"save_prefix\":\"\",\"enable_failed_object_recording\":true,\"enable_metadata_migration\":false,\"overwrite_mode\":\"SIZE_LAST_MODIFIED_COMPARISON_OVERWRITE\"}"
}
```

| 环境 | 链接 |
|------|------|
| 生产环境 | <a href="https://console.huaweicloud.com/oms/?region={目的端Region}#/oms/migrationTaskNew" target="_blank" rel="noopener noreferrer" style="display:block; margin-bottom:5px; color:#007bff; text-decoration:none;">OMS管理页面</a> |

---

## 参数校验规则

### 输入格式校验失败处理
当用户输入格式错误时：
- 明确告诉用户正确的格式
- 展示示例
- 保留当前步骤状态，等待用户重新输入
- 不切换到其他步骤

### 桶名称校验
- 不能为空
- 必须符合格式：`^[a-z0-9][a-z0-9.-]*[a-z0-9]$`
- 首尾必须是字母或数字，中间可包含`.`或`-`

### 前缀列表校验
- 不能为空
- 每个前缀必须是字符串
- 多个前缀用逗号分隔

### AK/SK校验
- 不能为空
- 最大长度100字符

### 描述字段校验（可选）
- 最大长度255字符
- 不能包含以下字符：`< > ( ) " ' &`

---

## 异常处理

| 异常场景 | 用户提示信息 |
|----------|--------------|
| SDK调用失败 | 展示详细报错信息（错误码、错误消息、状态码） |
| 不支持的Region | 不支持的Region: {region}，请从支持的Region列表中选择 |
| 无效的云服务商 | 不支持的云服务商: {cloud_type}，请从可选列表中选择 |
| 无效的AK/SK | AK/SK格式无效或认证信息不正确 |
| 桶名称格式错误 | 桶名称格式不正确，应为小写字母、数字、点号和连字符的组合 |
| 前缀为空 | 前缀列表不能为空 |
| 覆盖方式无效 | 同名对象覆盖方式必须是 CRC64_COMPARISON_OVERWRITE/NO_OVERWRITE/SIZE_LAST_MODIFIED_COMPARISON_OVERWRITE/FULL_OVERWRITE 之一 |
| 描述超长 | 描述长度{length}超过限制255字符 |
| 描述含非法字符 | 描述包含非法字符: < > ( ) " ' & |
| 保存前缀格式错误 | 保存前缀格式不正确：不能以.开头/结尾，不能以/开头，不能包含\:*?"<>|，不能包含两个以上相邻的/ |
| 桶不存在或无权访问 | 桶不存在或无权限访问，请检查桶名称和权限 |
| 网络/SDK错误 | 未知错误: {错误信息}，请稍后重试 |
| 凭证获取失败 | 凭证"{name}"获取AK/SK失败，请检查凭证是否有效 |
| OMS.0064参数错误 | 任务创建失败，请检查【已收集的任务数据】中的参数是否符合要求，参照参数说明进行修正 |

---