import sys
import os
# 获取 relay-agent 根目录
mgc_edge_home = os.environ.get('MgC_EDGE_HOME', 'C:\\RDA')
relay_path = os.path.join(mgc_edge_home, 'tools', 'plugins', 'relayagent', 'plugins', 'relayagent', 'bin', 'package', 'relay-core', 'src')
# 将 relay 源码路径添加到 sys.path
if str(relay_path) not in sys.path:
    sys.path.insert(0, str(relay_path))
# ========================================
from relay_core.infrastructure.external.rda_client.client import RdaClient
from typing import Optional

DEFAULT_MGC_EDGE_HOME = r'C:\RDA' if sys.platform == 'win32' else '/opt/cloud/RDA'
RDA_CONFIG_PATH = 'tools/plugins/relayagent/plugins/relayagent/config/rda-config.yaml'

def _get_mgc_edge_home() -> str:
    return os.environ.get('MgC_EDGE_HOME', DEFAULT_MGC_EDGE_HOME)

def _load_rda_config() -> dict:
    config_path = os.path.join(_get_mgc_edge_home(), RDA_CONFIG_PATH)
    if not os.path.exists(config_path):
        return {}
    try:
        with open(config_path, 'r', encoding='utf-8') as f:
            import yaml
            config = yaml.safe_load(f)
            return config if isinstance(config, dict) else {}
    except:
        return {}

class CredentialService:
    def __init__(self, rda_client: RdaClient):
        self.rda_client = rda_client
        self.rda_yaml_config = _load_rda_config()
        self.migrator = self.rda_yaml_config.get('relayagent')

    def list_credential(self, offset: int = 0, limit: int = 10, fuzzy_query_key: Optional[str] = None, fuzzy_query_value: Optional[str] = None) -> dict:
        try:
            params = [f'migrator={self.migrator}', f'offset={offset}', f'limit={limit}']
            if fuzzy_query_key:
                params.append(f'fuzzy_query_key={fuzzy_query_key}')
            if fuzzy_query_value:
                params.append(f'fuzzy_query_value={fuzzy_query_value}')
            path = '/v2/rda/openapi/credential?' + '&'.join(params)
            headers = {'Content-Type': 'application/json', 'encrypted': 'false'}
            response = self.rda_client.request(method='GET', path=path, headers=headers)
            if response.status_code == 200:
                return response.json()
            else:
                return {'error': f'HTTP {response.status_code}'}
        except Exception as e:
            return {'error': str(e)}

    def get_all_names(self) -> list:
        result = self.list_credential(offset=0, limit=10000)
        if 'error' in result:
            return []
        rows = result.get('data', {}).get('rows', [])
        return [row.get('name') for row in rows if row.get('name')]

    def get_ak_sk_by_name(self, name: str) -> dict:
        result = self.list_credential(offset=0, limit=10000)
        if 'error' in result:
            return {'error': result['error']}
        rows = result.get('data', {}).get('rows', [])
        for row in rows:
            if row.get('name') == name:
                return {'ak': row.get('cred_id'), 'sk': row.get('cred_secret')}
        return {'error': f'未找到名称为 {name} 的凭证'}
