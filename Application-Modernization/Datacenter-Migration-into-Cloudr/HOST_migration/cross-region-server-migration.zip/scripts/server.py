import uuid
from typing import Any
import ipaddress
import requests
import signer
import json


def query_project_id(region: str, cred: dict[str, str]) -> str:
    """查询华为云项目ID

    Args:
        region: 区域代码
        cred: 凭据字典，包含 ak 和 sk

    Returns:
        对应区域的项目ID，未找到返回 None
    """
    # Use IAM global endpoint to get all projects
    r = signer.HttpRequest("GET", f"https://iam.{region}.myhuaweicloud.com/v3/projects")
    sig = signer.Signer()
    sig.Key = cred["ak"]  # AK
    sig.Secret = cred["sk"]  # SK
    sig.Sign(r)

    resp = requests.request(
        r.method, r.scheme + "://" + r.host + r.uri,
        headers=r.headers, data=r.body,
        verify=False
    )

    result = json.loads(resp.content)
    project_id = next((p['id'] for p in result.get('projects', []) if p['name'] == region), None)
    return project_id


def list_servers(region: str, project_id: str, cred: dict[str, str]) -> str:
    """查询云服务器列表

    Args:
        region: 区域代码
        project_id: 项目ID
        cred: 凭据字典

    Returns:
        云服务器信息的 JSON 字符串，包含名称、ID、状态、规格、VPC、子网、卷等信息
    """
    sig = signer.Signer()
    sig.Key = cred["ak"]  # AK
    sig.Secret = cred["sk"]  # SK
    r = signer.HttpRequest("GET", f"https://ecs.{region}.myhuaweicloud.com/v1/{project_id}/cloudservers/detail")

    sig.Sign(r)

    resp = requests.request(r.method, r.scheme + "://" + r.host + r.uri, headers=r.headers, data=r.body,
                            verify=False)

    result = json.loads(resp.content)

    servers = result.get("servers", [])

    output = [{"ecs_name": s.get("name"), "ecs_id": s.get("id"),
               "status": s.get("status"),
               "flavor_id": s.get("flavor", {}).get("id"),
               "vpc_id": s.get("metadata", []).get("vpc_id"),
               "subnet_id": next(
                   (nic.get("subnet_id") for nic in s.get("network_interfaces", []) if nic.get("subnet_id")), None),
               "volume_id": next((vol.get("id") for vol in s.get("os-extended-volumes:volumes_attached", [])), None)}
              for s in
              servers]
    return json.dumps(output, indent=2, ensure_ascii=False)


def get_all_vpc_names(region: str, project_id: str, cred: dict[str, str]) -> dict[str, str]:
    """查询指定区域所有VPC的名称到ID映射

    Args:
        region: 区域代码
        project_id: 项目ID
        cred: 凭据字典

    Returns:
        VPC名称到ID的映射字典
    """
    sig = signer.Signer()
    sig.Key = cred["ak"]  # AK
    sig.Secret = cred["sk"]  # SK
    r = signer.HttpRequest("GET",
                           f"https://vpc.{region}.myhuaweicloud.com/v1/{project_id}/vpcs")
    sig.Sign(r)

    resp = requests.request(
        r.method, r.scheme + "://" + r.host + r.uri, headers=r.headers, data=r.body,
        verify=False
    )
    result = json.loads(resp.content)
    ans = result.get("vpcs", [])
    return {vpc["name"]: vpc["id"] for vpc in ans}


def show_vpc(region: str, project_id: str, vpc_id: str, cred: dict[str, str]) -> dict[str, Any]:
    """查询VPC详情

    Args:
        region: 区域代码
        project_id: 项目ID
        vpc_id: VPC ID
        cred: 凭据字典

    Returns:
        包含 cidr、name、description、enterprise_project_id 的字典
    """
    sig = signer.Signer()
    sig.Key = cred["ak"]  # AK
    sig.Secret = cred["sk"]  # SK
    r = signer.HttpRequest("GET",
                           f"https://vpc.{region}.myhuaweicloud.com/v1/{project_id}/vpcs/{vpc_id}")
    sig.Sign(r)

    resp = requests.request(
        r.method, r.scheme + "://" + r.host + r.uri,
        headers=r.headers, data=r.body,
        verify=False
    )

    result = json.loads(resp.content)
    vpc = result["vpc"]
    return {
        "cidr": vpc["cidr"],
        "name": vpc["name"],
        "description": vpc["description"],
        "enterprise_project_id": vpc["enterprise_project_id"]
    }


def create_vpc(region: str, project_id: str, vpc_config: dict[str, Any], cred: dict[str, str]) -> str | None:
    """创建VPC，若已存在则返回现有VPC ID

    Args:
        region: 区域代码
        project_id: 项目ID
        vpc_config: VPC配置，包含 name、description、cidr、enterprise_project_id
        cred: 凭据字典

    Returns:
        VPC ID，若创建失败返回 None
    """
    vpc_name = vpc_config.get("name")
    existing_vpc_names = get_all_vpc_names(region, project_id, cred)
    if vpc_name in existing_vpc_names:
        return existing_vpc_names[vpc_name]

    body = {
        "vpc": {
            "name": vpc_config.get("name"),
            "description": vpc_config.get("description", ""),
            "cidr": vpc_config.get("cidr"),
            "enterprise_project_id": vpc_config.get("enterprise_project_id", "0")
        }
    }
    sig = signer.Signer()
    sig.Key = cred["ak"]  # AK
    sig.Secret = cred["sk"]  # SK
    r = signer.HttpRequest("POST",
                           f"https://vpc.{region}.myhuaweicloud.com/v1/{project_id}/vpcs")
    r.body = json.dumps(body)
    r.headers = {"Content-Type": "application/json"}
    sig.Sign(r)
    resp = requests.request(
        r.method, r.scheme + "://" + r.host + r.uri,
        headers=r.headers,
        data=json.dumps(body),
        verify=False
    )
    result = json.loads(resp.content)
    return result["vpc"]["id"]


def show_subnet(region: str, project_id: str, subnet_id: str, cred: dict[str, str]) -> dict[str, Any]:
    """查询单个子网详情

    Args:
        region: 区域代码
        project_id: 项目ID
        subnet_id: 子网ID
        cred: 凭据字典

    Returns:
        包含 name、description、cidr、dnsList、vpc_id、gateway_ip 的字典
    """

    get_url = signer.HttpRequest("GET",
                                 f"https://vpc.{region}.myhuaweicloud.com/v1/{project_id}/subnets/{subnet_id}")
    sig = signer.Signer()
    sig.Key = cred["ak"]  # AK
    sig.Secret = cred["sk"]  # SK
    sig.Sign(get_url)

    resp = requests.request(get_url.method, get_url.scheme + "://" + get_url.host + get_url.uri,
                            headers=get_url.headers,
                            data=get_url.body,
                            verify=False)

    result = json.loads(resp.content)
    subnet = result.get("subnet", {})
    subnet_config = {
        "name": subnet.get("name"),
        "description": subnet.get("description"),
        "cidr": subnet.get("cidr"),
        "dnsList": subnet.get("dnsList"),
        "vpc_id": subnet.get("vpc_id"),
        "gateway_ip": subnet.get("gateway_ip")
    }

    return subnet_config


def list_subnet(region: str, project_id: str, cred: dict[str, str]) -> list[dict[str, Any]]:
    """查询区域内所有子网

    Args:
        region: 区域代码
        project_id: 项目ID
        cred: 凭据字典

    Returns:
        子网信息列表，每个子网包含 id、name、description、cidr、dnsList、vpc_id、gateway_ip
    """
    sig = signer.Signer()
    sig.Key = cred["ak"]  # AK
    sig.Secret = cred["sk"]  # SK
    subnet_configs = []
    get_url = signer.HttpRequest("GET", f"https://vpc.{region}.myhuaweicloud.com/v1/{project_id}/subnets")

    sig.Sign(get_url)

    resp = requests.request(get_url.method, get_url.scheme + "://" + get_url.host + get_url.uri,
                            headers=get_url.headers,
                            data=get_url.body,
                            verify=False)

    result = json.loads(resp.content)
    subnets = result.get("subnets", [])
    for subnet in subnets:
        filtered_result = {
            "id": subnet.get("id"),
            "name": subnet.get("name"),
            "description": subnet.get("description"),
            "cidr": subnet.get("cidr"),
            "dnsList": subnet.get("dnsList"),
            "vpc_id": subnet.get("vpc_id"),
            "gateway_ip": subnet.get("gateway_ip")
        }
        subnet_configs.append(filtered_result)

    return subnet_configs


def cidr_overlap(cidr1: str, cidr2: str) -> bool:
    """判断两个CIDR网段是否重叠

    Args:
        cidr1: CIDR网段1
        cidr2: CIDR网段2

    Returns:
        若重叠返回 True，否则返回 False
    """

    net1 = ipaddress.ip_network(cidr1, strict=False)
    net2 = ipaddress.ip_network(cidr2, strict=False)
    return net1.overlaps(net2)


def create_subnet(region: str, project_id: str, subnet_config: dict, cred: dict[str, str]) -> str:
    """创建子网，若同VPC下CIDR重叠则返回现有子网ID

    Args:
        region: 区域代码
        project_id: 项目ID
        subnet_config: 子网配置，包含 name、description、cidr、dnsList、vpc_id、gateway_ip
        cred: 凭据字典

    Returns:
        子网ID
    """
    existing_subnets = list_subnet(region, project_id, cred)
    target_vpc_id = subnet_config["vpc_id"]
    target_cidr = subnet_config["cidr"]

    for existing in existing_subnets:
        if existing["vpc_id"] == target_vpc_id and cidr_overlap(target_cidr, existing["cidr"]):
            return existing["id"]

    url = f"https://vpc.{region}.myhuaweicloud.com/v1/{project_id}/subnets"

    body = {
        "subnet": {
            "name": subnet_config["name"],
            "description": subnet_config["description"],
            "cidr": subnet_config["cidr"],
            "dnsList": subnet_config["dnsList"],
            "vpc_id": subnet_config["vpc_id"],
            "gateway_ip": subnet_config["gateway_ip"]
        }
    }
    sig = signer.Signer()
    sig.Key = cred["ak"]  # AK
    sig.Secret = cred["sk"]  # SK
    get_url = signer.HttpRequest("POST", url)
    get_url.body = json.dumps(body)
    get_url.headers = {"Content-Type": "application/json"}
    sig.Sign(get_url)

    resp = requests.request(get_url.method, get_url.scheme + "://" + get_url.host + get_url.uri,
                            headers=get_url.headers,
                            data=json.dumps(body),
                            verify=False)
    subnet_details = json.loads(resp.content)
    return subnet_details["subnet"]["id"]


def show_volume(region: str, project_id: str, volume_id: str, cred: dict[str, str]) -> dict[str, Any]:
    """查询云硬盘详情

    Args:
        region: 区域代码
        project_id: 项目ID
        volume_id: 云硬盘ID
        cred: 凭据字典

    Returns:
        包含 volume_type 和 size 的字典
    """
    sig = signer.Signer()
    sig.Key = cred["ak"]  # AK
    sig.Secret = cred["sk"]  # SK
    r = signer.HttpRequest("GET",
                           f"https://evs.{region}.myhuaweicloud.com/v2/{project_id}/cloudvolumes/{volume_id}")
    sig.Sign(r)

    resp = requests.request(
        r.method, r.scheme + "://" + r.host + r.uri,
        headers=r.headers, data=r.body,
        verify=False
    )

    result = json.loads(resp.content)
    volume = result["volume"]
    return {
        "volume_type": volume["volume_type"],
        "size": volume["size"],
    }


def merge_server_ids(server_conf: dict[str, Any]) -> list[str]:
    """提取服务器配置中所有服务器的ID

    Args:
        server_conf: 服务器配置字典，值为包含 id 字段的字典

    Returns:
        所有服务器ID的列表
    """
    return [server["id"] for server in server_conf.values() if "id" in server]


def sum_volume_sizes(server_conf: dict[str, Any]) -> int:
    """计算服务器配置中所有卷的总大小

    Args:
        server_conf: 服务器配置字典，值为包含 volume_size 的字典

    Returns:
        所有卷大小的总和
    """
    total = 0
    for conf in server_conf.values():
        volume_size = conf.get("volume_size")
        if volume_size:
            total += int(volume_size)
    return total


def create_vault(region: str, project_id: str, protect_type: str, volume_size: int,
                 consistent_level: str, ecs_name: str, ecs_id: str, cred: dict[str, str]) -> str | None:
    """创建CBR存储库

    Args:
        region: 区域代码
        project_id: 项目ID
        protect_type: 保护类型
        volume_size: 卷大小
        consistent_level: 一致性级别
        ecs_name: 服务器名称
        ecs_id: 服务器id
        cred: 凭据字典

    Returns:
        存储库ID，创建失败返回 None
    """
    sig = signer.Signer()
    sig.Key = cred["ak"]  # AK
    sig.Secret = cred["sk"]  # SK
    vault_body = {
        "vault": {
            "billing": {
                "cloud_type": "public",
                "consistent_level": consistent_level,
                "object_type": "server",
                "protect_type": protect_type,
                "size": int(volume_size * 3 / 2),
                "charging_mode": "post_paid",
                "is_auto_renew": False,
                "is_auto_pay": False,
                "is_multi_az": False
            },
            "name": f"vault-{ecs_name}",
            "resources": [
                {
                    "id": ecs_id,
                    "type": "OS::Nova::Server"
                }
            ],
        }
    }

    r = signer.HttpRequest("POST", f"https://cbr.{region}.myhuaweicloud.com/v3/{project_id}/vaults")
    r.body = json.dumps(vault_body)
    r.headers = {"Content-Type": "application/json"}

    sig.Sign(r)

    resp = requests.request(
        r.method, r.scheme + "://" + r.host + r.uri,
        headers=r.headers, data=r.body,
        verify=False
    )

    result = json.loads(resp.content)
    vault_id = result.get("vault", {}).get("id") if "vault" in result else None
    return vault_id


def create_checkpoints(region: str, project_id: str, vault_id: str, name: str, cred: dict[str, str]) -> dict[str, Any]:
    """创建备份检查点

    Args:
        region: 区域代码
        project_id: 项目ID
        vault_id: 存储库ID
        name: 服务器名称
        cred: 凭据字典

    Returns:
        API响应结果，包含检查点信息
    """
    sig = signer.Signer()
    sig.Key = cred["ak"]  # AK
    sig.Secret = cred["sk"]  # SK
    source_endpoint = f"https://cbr.{region}.myhuaweicloud.com"

    vault_body = {
        "checkpoint": {
            "vault_id": vault_id
        }
    }

    r = signer.HttpRequest("POST", f"{source_endpoint}/v3/{project_id}/checkpoints")
    r.body = json.dumps(vault_body)
    r.headers = {"Content-Type": "application/json"}

    sig.Sign(r)

    resp = requests.request(
        r.method, r.scheme + "://" + r.host + r.uri,
        headers=r.headers, data=r.body,
        verify=False
    )

    result = json.loads(resp.content)
    return result


def show_checkpoint(region: str, project_id: str, checkpoint_id: str, cred: dict[str, str]) -> str:
    """查询备份检查点状态

    Args:
        region: 区域代码
        project_id: 项目ID
        checkpoint_id: 检查点ID
        cred: 凭据字典

    Returns:
        检查点状态字符串
    """
    sig = signer.Signer()
    sig.Key = cred["ak"]  # AK
    sig.Secret = cred["sk"]  # SK
    r = signer.HttpRequest("GET",
                           f"https://cbr.{region}.myhuaweicloud.com/v3/{project_id}/checkpoints/{checkpoint_id}")
    sig.Sign(r)

    resp = requests.request(
        r.method, r.scheme + "://" + r.host + r.uri,
        headers=r.headers, data=r.body,
        verify=False
    )

    result = json.loads(resp.content)
    status = result["checkpoint"]["status"]
    return status


def copy_checkpoint(region: str, project_id: str, vault_id: str, destination_region: str, destination_project_id: str,
                    destination_vault_id: str, cred: dict[str, str]
                    ) -> list[Any]:
    """跨区域复制备份

    Args:
        region: 源端区域代码
        project_id: 源端项目ID
        vault_id: 源端存储库ID
        destination_region: 目的端区域代码
        destination_project_id: 目的端项目ID
        destination_vault_id: 目的端存储库ID
        cred: 凭据字典

    Returns:
        复制产生的备份ID列表
    """
    sig = signer.Signer()
    sig.Key = cred["ak"]  # AK
    sig.Secret = cred["sk"]  # SK
    body = {
        "replicate": {
            "destination_project_id": destination_project_id,
            "destination_region": destination_region,
            "destination_vault_id": destination_vault_id,
            "vault_id": vault_id
        }
    }

    r = signer.HttpRequest("POST",
                           f"https://cbr.{region}.myhuaweicloud.com/v3/{project_id}/checkpoints/replicate")

    r.body = json.dumps(body)
    r.headers = {"Content-Type": "application/json"}
    sig.Sign(r)
    resp = requests.request(
        r.method, r.scheme + "://" + r.host + r.uri,
        headers=r.headers, data=r.body,
        verify=False
    )

    result = json.loads(resp.content)
    return [b["backup_id"] for b in result.get("replication", {}).get("backups", [])]


def list_backups(region: str, project_id: str, vault_id: str, cred: dict[str, str]) -> dict[str, Any]:
    """查询指定存储库的最新备份

    Args:
        region: 区域代码
        project_id: 项目ID
        vault_id: 存储库ID
        cred: 凭据字典

    Returns:
        包含 checkpoint_id 和 status 的字典，若无备份返回空字典
    """
    sig = signer.Signer()
    sig.Key = cred["ak"]  # AK
    sig.Secret = cred["sk"]  # SK
    r = signer.HttpRequest("GET",
                           f"https://cbr.{region}.myhuaweicloud.com/v3/{project_id}/backups")
    sig.Sign(r)

    resp = requests.request(
        r.method, r.scheme + "://" + r.host + r.uri,
        headers=r.headers, data=r.body,
        verify=False
    )

    result = json.loads(resp.content)
    backups = result.get("backups", [])
    if not backups:
        return {}

    filtered_backups = [b for b in backups if b.get("vault_id") == vault_id]

    latest_backup = None
    for backup in filtered_backups:
        if latest_backup is None or backup.get("created_at", "") > latest_backup.get("created_at", ""):
            latest_backup = backup

    if latest_backup is None:
        return {}

    return {
        "backup_id": latest_backup.get("id"),
        "status": latest_backup.get("status")
    }


def create_image(region: str, backup_id: str, name: str, cred: dict[str, str]) -> dict[str, Any]:
    """基于备份创建镜像

    Args:
        region: 区域代码
        backup_id: 备份ID
        cred: 凭据字典

    Returns:
        API响应结果，包含镜像ID和状态
    """
    vault_body = {
        "name": f"image-{name}",
        "backup_id": backup_id,
        "whole_image_type": "CBR"
    }
    sig = signer.Signer()
    sig.Key = cred["ak"]  # AK
    sig.Secret = cred["sk"]  # SK
    r = signer.HttpRequest("POST", f"https://ims.{region}.myhuaweicloud.com/v1/cloudimages/wholeimages/action")
    r.body = json.dumps(vault_body)
    r.headers = {"Content-Type": "application/json"}

    sig.Sign(r)

    resp = requests.request(
        r.method, r.scheme + "://" + r.host + r.uri,
        headers=r.headers, data=r.body,
        verify=False
    )

    result = json.loads(resp.content)
    return result


def show_job_progress(job_id: str, region: str, cred: dict[str, str]) -> dict[str, Any]:
    """查询镜像创建任务进度

    Args:
        job_id: 任务ID
        region: 区域代码
        cred: 凭据字典

    Returns:
        包含 image_id 和 status 的字典
    """
    r = signer.HttpRequest("GET", f"https://ims.{region}.myhuaweicloud.com/v1/cloudimages/job/{job_id}")
    sig = signer.Signer()
    sig.Key = cred["ak"]  # AK
    sig.Secret = cred["sk"]  # SK
    sig.Sign(r)

    resp = requests.request(
        r.method, r.scheme + "://" + r.host + r.uri,
        headers=r.headers, data=r.body,
        verify=False
    )

    result = json.loads(resp.content)
    entities = result.get("entities", {})
    return {
        "image_id": entities.get("image_id"),
        "status": result.get("status")
    }


def create_server(region: str, project_id: str, flavorRef: str, imageRef: str, ecs_name: str, vpc_id: str,
                  subnet_id: str, volume_type: str, cred: dict[str, str]) -> dict[str, Any]:
    """创建云服务器

    Args:
        region: 区域代码
        project_id: 项目ID
        flavorRef: 规格ID
        imageRef: 镜像ID
        ecs_name: 云服务器名称
        vpcid: VPC ID
        subnet_id: 子网ID
        volume_type: 根卷类型
        cred: 凭据字典

    Returns:
        API响应结果，包含云服务器信息
    """
    sig = signer.Signer()
    sig.Key = cred["ak"]  # AK
    sig.Secret = cred["sk"]  # SK
    server_body = {
        "server": {
            "flavorRef": flavorRef,
            "imageRef": imageRef,
            "name": ecs_name,
            "nics": [{"subnet_id": subnet_id}],
            "root_volume": {
                "volumetype": volume_type
            },
            "vpcid": vpc_id
        }
    }

    r = signer.HttpRequest("POST", f"https://ecs.{region}.myhuaweicloud.com/v1/{project_id}/cloudservers")
    r.body = json.dumps(server_body)
    r.headers = {"Content-Type": "application/json"}

    sig.Sign(r)

    resp = requests.request(
        r.method, r.scheme + "://" + r.host + r.uri,
        headers=r.headers, data=r.body,
        verify=False
    )

    result = json.loads(resp.content)
    return result


def delete_vault(region: str, project_id: str, vault_id: str, cred: dict[str, str]) -> None:
    """删除存储库

    Args:
        region: 区域代码
        project_id: 项目ID
        vault_id: 存储库ID
        cred: 凭据字典
    """
    sig = signer.Signer()
    sig.Key = cred["ak"]  # AK
    sig.Secret = cred["sk"]  # SK
    r = signer.HttpRequest("DELETE", f"https://cbr.{region}.myhuaweicloud.com/v3/{project_id}/vaults/{vault_id}")

    sig.Sign(r)

    resp = requests.request(
        r.method, r.scheme + "://" + r.host + r.uri,
        headers=r.headers, data=r.body,
        verify=False
    )


def delete_image(region: str, image_id: str, cred: dict[str, str]) -> None:
    """删除镜像

    Args:
        region: 区域代码
        image_id: 镜像ID
        cred: 凭据字典
    """
    sig = signer.Signer()
    sig.Key = cred["ak"]  # AK
    sig.Secret = cred["sk"]  # SK
    r = signer.HttpRequest("DELETE", f"https://ims.{region}.myhuaweicloud.com/v2/images/{image_id}")

    sig.Sign(r)

    resp = requests.request(
        r.method, r.scheme + "://" + r.host + r.uri,
        headers=r.headers, data=r.body,
        verify=False
    )
