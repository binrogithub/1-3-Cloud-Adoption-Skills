# API 参数与响应

本文档包含所有 server.py API 函数的参数和响应示例。

## 目录

- [get_credential](#get_credential)
- [query_project_id](#query_project_id)
- [list_servers](#list_servers)
- [show_vpc](#show_vpc)
- [create_vpc](#create_vpc)
- [show_subnet](#show_subnet)
- [create_subnet](#create_subnet)
- [show_volume](#show_volume)
- [create_vault](#create_vault)
- [add_resource](#add_resource)
- [create_checkpoints](#create_checkpoints)
- [show_checkpoint](#show_checkpoint)
- [copy_checkpoint](#copy_checkpoint)
- [list_backups](#list_backups)
- [create_image](#create_image)
- [show_job_progress](#show_job_progress)
- [create_server](#create_server)
- [delete_image](#delete_image)
- [delete_vault](#delete_vault)

 ---

## get_ak_sk_by_name

获取凭证ak/sk。

**参数：**

 ```json
 {
  "name": "凭证名称"
}
 ```

**响应：**

 ```json
 {
  "ak": "ak",
  "sk": "sk"
}
 ```

 ---

## query_project_id

查询指定 region 的 project_id。

**参数：**

 ```json
 {
  "region_id": "region_id",
  "cred": {
    "ak": "ak",
    "sk": "sk"
  }
}
 ```

**响应：**

 ```json
 {
  "project_id": "xxx"
}
 ```

 ---

## list_servers

查询区域内的主机列表。

**参数：**

 ```json
 {
  "region_id": "region_id",
  "project_id": "project_id",
  "cred": {
    "ak": "ak",
    "sk": "sk"
  }
}
 ```

**响应：**

 ```json
 [
  {
    "ecs_name": "ecs1",
    "ecs_id": "a12b325f-1d3e-4125-ab9a-cda8d71a094d",
    "status": "ACTIVE",
    "flavor_id": "c3.xlarge.2",
    "vpc_id": "f81f4aef-c1c2-120b-114d-1bdc41af1110",
    "subnet_ids": "106114e7-f117-411f-1111-3f1d0a5e11a9",
    "volume_id": "111c8b3e-a111-4b9f-bec1-cf1e1fbf11e7"
  }
]
 ```

 ---

## show_vpc

查询 VPC 详情。

**参数：**

 ```json
 {
  "region": "region_id",
  "project_id": "project_id",
  "vpc_id": "vpc_id",
  "cred": {
    "ak": "ak",
    "sk": "sk"
  }
}
 ```

**响应：**

 ```json
 {
  "cidr": "192.168.0.0/16",
  "name": "vpc-xx",
  "description": "",
  "enterprise_project_id": "0"
}
 ```

 ---

## create_vpc

在目标区域创建 VPC。

**参数：**

 ```json
 {
  "region": "region_id",
  "project_id": "project_id",
  "vpc_config": {
    "cidr": "192.168.0.0/16",
    "name": "vpc-xx",
    "description": "",
    "enterprise_project_id": "0"
  },
  "cred": {
    "ak": "ak",
    "sk": "sk"
  }
}
 ```

**响应：**

 ```json
 {
  "vpc_id": "xxx"
}
 ```

 ---

## show_subnet

查询子网详情。

**参数：**

 ```json
 {
  "region": "region_id",
  "project_id": "project_id",
  "subnet_id": "subnet_id",
  "cred": {
    "ak": "ak",
    "sk": "sk"
  }
}
 ```

**响应：**

 ```json
 [
  {
    "name": "subnet-1241",
    "description": "",
    "cidr": "192.168.0.0/24",
    "dnsList": [
      "100.11.12.230",
      "100.11.21.230"
    ],
    "vpc_id": "e2354233-0572-44fb-8016-674eb0287461",
    "gateway_ip": "192.168.0.1"
  }
]
 ```

 ---

## create_subnet

在目标区域创建子网。

**参数：**

 ```json
 {
  "region": "region_id",
  "project_id": "project_id",
  "subnet_config": {
    "name": "subnet-1241",
    "description": "",
    "cidr": "192.168.0.0/24",
    "dnsList": [
      "100.11.12.230",
      "100.11.21.230"
    ],
    "vpc_id": "target_vpc_id",
    "gateway_ip": "192.168.0.1"
  },
  "cred": {
    "ak": "ak",
    "sk": "sk"
  }
}
 ```

**响应：**

 ```json
 {
  "subnet_id": "xxxx"
}
 ```

 ---

## show_volume

查询硬盘详情。

**参数：**

 ```json
 {
  "region": "region_id",
  "project_id": "project_id",
  "volume_id": "volume_id",
  "cred": {
    "ak": "ak",
    "sk": "sk"
  }
}
 ```

**响应：**

 ```json
 {
  "volume_type": "GPSSD",
  "size": 40
}
 ```

 ---

## create_vault

创建 CBR 存储库。

**参数：**

 ```json
 {
  "region": "region_id",
  "project_id": "project_id",
  "protect_type": "backup | replication",
  "volume_size": 40,
  "consistent_level": "app_consistent | crash_consistent",
  "ecs_name": "server-conf中的主机名称name",
  "cred": {
    "ak": "ak",
    "sk": "sk"
  }
}
 ```

| 字段               | 源端存储库          | 目的端存储库           |
 |------------------|----------------|------------------|
| protect_type     | backup         | replication      |
| consistent_level | app_consistent | crash_consistent |

**响应：**

 ```json
 {
  "vault_id": "xxx"
}
 ```

 ---

## add_resource

为存储库添加主机资源。

**参数：**

 ```json
 {
  "ecs_id": "主机ID",
  "region": "源端region_id",
  "project_id": "source_project_id",
  "vault_id": "source_vault_id",
  "cred": {
    "ak": "ak",
    "sk": "sk"
  }
}
 ```

**响应：**

 ```json
 {
  "add_resource_ids": [
    "e8cc6bfd-d324-4b88-9109-9fb0ba70676f"
  ]
}
 ```

 ---

## create_checkpoints

创建备份点。

**参数：**

 ```json
 {
  "region": "源端region_id",
  "project_id": "source_project_id",
  "vault_id": "source_vault_id",
  "name": "主机名称",
  "cred": {
    "ak": "ak",
    "sk": "sk"
  }
}
 ```

**响应：**

 ```json
 {
  "checkpoint_id": "xxx"
}
 ```

 ---

## show_checkpoint

查询备份点状态。

**参数：**

 ```json
 {
  "region": "源端region_id",
  "project_id": "source_project_id",
  "checkpoint_id": "checkpoint_id",
  "cred": {
    "ak": "ak",
    "sk": "sk"
  }
}
 ```

**响应：**

 ```json
 "available"
 ```

状态为 `available` 时表示备份成功。

 ---

## copy_checkpoint

创建跨区域复制备份。

**参数：**

 ```json
 {
  "region": "源端region_id",
  "project_id": "源端project_id",
  "vault_id": "源端vault_id",
  "destination_region": "目的端region_id",
  "destination_project_id": "目的端project_id",
  "destination_vault_id": "目的端vault_id",
  "cred": {
    "ak": "ak",
    "sk": "sk"
  }
}
 ```

**响应：**

 ```json
 {
  "backup_id": "123456"
}
 ```

 ---

## list_backups

查询备份列表。

**参数：**

 ```json
 {
  "region": "目的端region_id",
  "project_id": "目的端project_id",
  "vault_id": "目的端vault_id",
  "cred": {
    "ak": "ak",
    "sk": "sk"
  }
}
 ```

**响应：**

 ```json
 {
  "backup_id": "33014c74-8c42-4499-89c5-f08b7afc67c7",
  "status": "available"
}
 ```

状态为 `available` 时表示备份可用。

 ---

## create_image

创建整机镜像。

**参数：**

 ```json
 {
  "region": "目的端region_id",
  "backup_id": "backup_id",
  "name": "主机名称",
  "cred": {
    "ak": "ak",
    "sk": "sk"
  }
}
 ```

**响应：**

 ```json
 {
  "job_id": "123456"
}
 ```

 ---

## show_job_progress

查询任务进度。

**参数：**

 ```json
 {
  "job_id": "job_id",
  "region": "目的端region_id",
  "cred": {
    "ak": "ak",
    "sk": "sk"
  }
}
 ```

**响应：**

 ```json
 {
  "image_id": "4dfece00-58bc-4c9c-82f2-2836d5b602df",
  "status": "SUCCESS"
}
 ```

状态为 `SUCCESS` 时表示任务完成。

 ---

## create_server

创建目标主机。

**参数：**

 ```json
 {
  "region": "目的端region_id",
  "project_id": "目的端project_id",
  "flavorRef": "flavor_id",
  "imageRef": "image_id",
  "ecs_name": "主机名称",
  "vpc_id": "target_vpc_id",
  "subnet_id": "target_subnet_id",
  "volume_type": "volume_type",
  "cred": {
    "ak": "ak",
    "sk": "sk"
  }
}
 ```

**响应：**

 ```json
 {
  "server_id": "123456"
}
 ```

 ---

## delete_image

删除镜像。

**参数：**

 ```json
 {
  "region": "目的端region_id",
  "image_id": "image_id",
  "cred": {
    "ak": "ak",
    "sk": "sk"
  }
}
 ```

**响应：** 无

 ---

## delete_vault

删除存储库。

**参数：**

 ```json
 {
  "region": "region_id",
  "project_id": "project_id",
  "vault_id": "vault_id",
  "cred": {
    "ak": "ak",
    "sk": "sk"
  }
}
 ```

**响应：** 无
