| 显示名称 | Region ID |
|----------|-----------|
| 华北-北京一 | cn-north-1 |
| 华北-北京二 | cn-north-2 |
| 华北-北京四 | cn-north-4 |
| 华东-上海二 | cn-east-2 |
| 华东-上海一 | cn-east-3 |
| 华东二 | cn-east-4 |
| 华东-青岛 | cn-east-5 |
| 华南-广州 | cn-south-1 |
