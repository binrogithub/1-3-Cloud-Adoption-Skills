# server_conf 数据结构

## 概述

`server_conf` 是一个 JSON 列表，每个元素对应一台待迁移主机，包含迁移所需的所有配置信息。

## 数据结构

 ```json
 [
  {
    "ecs_id": "主机ID",
    "ecs_name": "ecs-1",
    "image_id": "镜像id",
    "source_vault_id": "源端存储库id",
    "source_checkpoint_id": "源端备份id",
    "target_vault_id": "目的端存储库id",
    "target_backup_id": "目的端备份id",
    "flavor_id": "规格",
    "source_vpc_id": "源端vpc_id",
    "target_vpc_id": "目的端vpc_id",
    "vpc_config": {
      "cidr": "192.168.0.0/16",
      "name": "vpc-xx",
      "description": "",
      "enterprise_project_id": "0"
    },
    "source_subnet_id": "源端子网id",
    "target_subnet_id": "目的子网id",
    "subnet_config": {
      "name": "subnet-1241",
      "description": "",
      "cidr": "192.168.0.0/24",
      "dnsList": [
        "100.11.12.230",
        "100.11.21.230"
      ],
      "vpc_id": "vpc_id",
      "gateway_ip": "192.168.0.1"
    },
    "volume_id": "硬盘id",
    "volume_type": "硬盘类型",
    "volume_size": "硬盘大小"
  }
]
 ```

## 字段说明

| 字段                   | 来源                           | 说明         |
 |----------------------|------------------------------|------------|
| ecs_id               | list_servers 返回              | 主机 ID      |
| ecs_name             | list_servers 返回              | 主机名称       |
| flavor_id            | list_servers 返回              | 实例规格       |
| source_vpc_id        | list_servers 返回的 vpc_id      | 源端 VPC     |
| source_subnet_id     | list_servers 返回的 subnet_ids  | 源端子网       |
| volume_id            | list_servers 返回              | 硬盘 ID      |
| image_id             | 步骤17返回                       | 整机镜像 ID    |
| source_vault_id      | 步骤10返回                       | 源端存储库 ID   |
| source_checkpoint_id | 步骤12返回                       | 源端备份点 ID   |
| target_vault_id      | 步骤10返回                       | 目的端存储库 ID  |
| target_backup_id     | 步骤15返回                       | 目的端备份 ID   |
| target_vpc_id        | 步骤6返回                        | 目的端 VPC ID |
| target_subnet_id     | 步骤8返回                        | 目的端子网 ID   |
| vpc_config           | 步骤5查询结果                      | VPC 配置信息   |
| subnet_config        | 步骤7查询结果                      | 子网配置信息     |
| volume_type          | 步骤9查询结果                      | 硬盘类型       |
| volume_size          | 步骤9查询结果                      | 硬盘大小       |


# task_management 数据结构

## 概述

`task_management` 是一个 JSON 列表，每个元素对应迁移任务的状态，包含迁移任务完成到哪一步。

## 数据结构

 ```json
 [
  {
    "AK": "AK",
    "SK": "SK",
    "source_region": "源端区域id，例如：cn-north-1",
    "target_region": "目的端区域id，例如：cn-north-4",
    "source_project_id": "源端项目id",
    "target_project_id": "目的端项目id",
    "step1_completed": "true",
    "step2_completed": "false",
    "step3_completed": "true",
    "step4_completed": "true",
    "step5_completed": "false",
    "step6_completed": "false",
    "step7_completed": "true",
    "step8_completed": "false",
    "step9_completed": "true",
    "step10_completed": "false",
    "step11_completed": "true",
    "step12_completed": "false",
    "step13_completed": "false",
    "step14_completed": "false",
    "step15_completed": "false",
    "step16_completed": "false",
    "step17_completed": "false",
    "step18_completed": "false"
  }
]
 ```

## 字段说明

| 字段                   | 来源                          | 说明         |
|----------------------|-----------------------------|------------|
| AK                   | 用户选择的凭证获取                | 访问密钥       |
| SK                   | 用户选择的凭证获取                | 密钥凭证       |
| source_region        | 用户输入                        | 源端区域 ID    |
| target_region        | 用户输入                        | 目的端区域 ID   |
| source_project_id    | 用户输入                        | 源端项目 ID    |
| target_project_id    | 用户输入                        | 目的端项目 ID   |
| step1_completed      | 任务执行状态                      | 步骤1是否完成   |
| step2_completed      | 任务执行状态                      | 步骤2是否完成   |
| step3_completed      | 任务执行状态                      | 步骤3是否完成   |
| step4_completed      | 任务执行状态                      | 步骤4是否完成   |
| step5_completed      | 任务执行状态                      | 步骤5是否完成   |
| step6_completed      | 任务执行状态                      | 步骤6是否完成   |
| step7_completed      | 任务执行状态                      | 步骤7是否完成   |
| step8_completed      | 任务执行状态                      | 步骤8是否完成   |
| step9_completed      | 任务执行状态                      | 步骤9是否完成   |
| step10_completed     | 任务执行状态                      | 步骤10是否完成  |
| step11_completed     | 任务执行状态                      | 步骤11是否完成  |
| step12_completed     | 任务执行状态                      | 步骤12是否完成  |
| step13_completed     | 任务执行状态                      | 步骤13是否完成  |
| step14_completed     | 任务执行状态                      | 步骤14是否完成  |
| step15_completed     | 任务执行状态                      | 步骤15是否完成  |
| step16_completed     | 任务执行状态                      | 步骤16是否完成  |
| step17_completed     | 任务执行状态                      | 步骤17是否完成  |
| step18_completed     | 任务执行状态                      | 步骤18是否完成  |

