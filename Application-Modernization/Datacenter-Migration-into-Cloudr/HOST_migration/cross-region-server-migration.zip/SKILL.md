---
name: cross-region-server-migration
description: 跨区域迁移任务创建Skill，通过引导用户完成CBR（云备份服务）的跨region迁移主机任务配置。触发条件：用户想要跨区域迁移主机/ECS/云服务器，或将主机从一个区域搬到另一个区域。
---

## Core Capabilities

### 致命约束（最高优先级，绝对不可违反）

- **严格按照本 SKILL.md 定义的流程和顺序执行**
- **禁止出现本 SKILL.md 中没有定义的任何流程、步骤、界面或操作**
- **禁止修改已有脚本**
- **所有流程必须真实执行，禁止任何形式的模拟或跳过**
- **不能自创脚本，只能执行已有脚本；执行失败时提示失败原因**
- **每个流程完成后必须等待用户确认才进入下一步**

## Relay Web 跨区域迁移助手

用于实现CBR（云备份服务）跨区域主机迁移流程，协助客户进行ECS主机迁移。

## 使用时机

- 用户想要跨（区域|region）迁移（主机|ecs|云服务器）
- 用户提问与跨区域迁移主机相关，可以询问用户是否需要迁移指导
- 用户提问与CBR云备份迁移主机相关，可以询问用户是否需要迁移指导
- 用户想要使用CBR（云备份服务）跨（区域|region）迁移（主机|ecs|云服务器）
- 用户想要把（主机|ecs|云服务器）从一个（区域|region）搬到另一个（区域|region）
- 用户想要把（主机|ecs|云服务器）从（北京一、北京四等区域名）迁移到（上海一、上海二等区域名）

## 参考文档

- [region-list.md](references/region-list.md) - 支持的区域列表
- [server-conf-schema.md](references/server-conf-schema.md) - server_conf 数据结构说明
- [api-parameters.md](references/api-parameters.md) - 所有 API 函数参数和响应示例
- [faq.md](references/faq.md) - 常见问题的faq

## 详细流程

### 步骤1：凭证设置与API访问密钥

**⚠️ 禁止自行添加选项：本步骤只有以下5个子步骤，Agent禁止添加任何其他选项或步骤**
**⚠️ 1.1 重要提示：**
在继续之前，请先在MgC-Lite中保存您的华为云AK/SK凭证，路径为**设置 → 凭证管理**。
**获取到AK/SK后，请将凭证保存到凭证管理中，保存成功后继续下一步。**

**1.2 获取可用凭证列表：**
Agent执行以下命令获取已保存的凭证列表：

```
$ python -c "
import sys
import os
# 添加skill目录到路径
skill_dir = os.path.join(os.getcwd(), '.skills', 'cross-region-server', 'scripts')
sys.path.insert(0, skill_dir)
from list_credentials import CredentialService
from relay_core.infrastructure.external.rda_client.client import RdaClient

# 创建RdaClient实例
rda_client = RdaClient()
cred_service = CredentialService(rda_client)

# 获取凭证列表
credentials = cred_service.get_all_names()
print('可用凭证列表:', credentials)
"
```

如果获取凭证失败，提示用户检查是否已经在MgC-Lite中配置了凭证，并等待用户确认配置成功后重新获取凭证。

**1.3 展示获取到的凭证列表：**
让用户确认并选择要使用的凭证，展示结果示例。

```
可用凭证列表: ['credential_1', 'credential_2', 'my_ak_sk']
```

等待用户确认，。
注意：如果只有一个凭证也必须让用户选择并确认。

** 1.4 让用户从列表选择**
请从列表中选择用于调用华为云 API的凭证：
**注意: 获取的AK/SK不要展示给用户, 不要输出**

** 1.5 根据用户选择的凭证名称获取AK/SK
调用`list_credentials.py`的`get_ak_sk_by_name`函数（详见 [api-parameters.md](references/api-parameters#get_ak_sk_by_name)
），传入获取的凭证名称，返回的值为凭证cred，作为后续步骤参数使用。

---

### 步骤2 获取源端region和目的端region

调用`ask_user`工具渲染源端region和目的端region选项框,并等待用户选择(注意仅支持单选)。

region 列表详见 [region-list.md](references/region-list.md)。

用户输入后告知用户选择的源端region和目的端region参数是什么。

---

### 步骤3 获取源端region的project_id和目的端region的project_id

分别传入源端region_id和目的端region_id，调用`server.py`的`query_project_id`
函数（详见 [api-parameters.md](references/api-parameters#query_project_id)）。

将源端region_id获取的结果记录为`source_project_id`，将目的端获取的结果记录为`target_project_id`。

---

### 步骤4 获取源端待迁移主机列表

传入步骤3获取的source_project_id，调用`server.py`的`list_servers`
函数（详见 [api-parameters.md](references/api-parameters#list_servers)），查询出主机列表，返回的是一个json格式的字符串而不是列表。

将查询结果的部分值ecs_id、ecs_name、status、flavor_id提取出来,调用`ask_user`
工具渲染源端待迁移主机选项框，并等待用户选择，其余的参数后续步骤会使用。提示用户每次迁移不超过5台最佳。
提示用户：当前未显示的主机可以在other选项框中手动输入主机id，用逗号连接。

- 展示格式：每行显示 `ecs_name | ecs_id  | status | flavor_id`

用户选择后，告知用户选择的主机ID列表，并根据选择的主机数，记录一个json列表`server_conf`
（详见 [server-conf-schema.md](references/server-conf-schema.md)），用来保存已选择主机的配置信息。

---

### 步骤5 查询源端vpc

分别传入步骤3获取的源端region_id和source_project_id，以及`server_conf`中的source_vpc_id，调用`server.py`的`show_vpc`
函数（详见 [api-parameters.md](references/api-parameters#show_vpc)），查询vpc源端的vpc信息，将查询到的结果存到
`server_conf`中对应server的vpc_config。

---

### 步骤6 创建目的端vpc

分别将步骤5查询到的vpc配置信息`vpc_config`传入，调用`server.py`的`create_vpc`
函数（详见 [api-parameters.md](references/api-parameters#create_vpc)），在目的端创建出相同配置的vpc。并将返回的vpc_id保存到
`server_conf`中对应的target_vpc_id。

告知客户目的端vpc已创建。

如果创建失败，提示用户检查目的端是否还有配额，并等待用户确认后重新创建。

---

### 步骤7 查询源端子网

分别传入步骤3获取的源端region_id和source_project_id，以及步骤5的source_subnet_id，调用`server.py`的`show_subnet`
函数（详见 [api-parameters.md](references/api-parameters#show_subnet)），查询源端的子网信息，将查询到的结果存到
`server_conf`中对应的subnet_config。

---

### 步骤8 创建目的端子网

分别将记录在`server_conf`中的子网配置信息`subnet_config`传入，调用`server.py`的`create_subnet`
函数（详见 [api-parameters.md](references/api-parameters#create_subnet)），在目的端创建出相同配置的子网。并将返回的subnet_id保存到
`server_conf`中对应的target_subnet_id。

告知客户目的端子网已创建。

如果创建失败，提示用户检查目的端是否还有配额，并等待用户确认后重新创建。
---

### 步骤9 查询源端磁盘类型和大小

分别传入步骤3获取的源端region_id和source_project_id，以及`server_conf`中的volume_id，调用`server.py`的`show_volume`
函数（详见 [api-parameters.md](references/api-parameters#show_volume)），分别查询源端的磁盘信息，将查询到的结果存到
`server_conf`中对应的volume_type和volume_size中。

---

### 步骤10 创建源端和目的端CBR存储库

调用`server.py`的`create_vault`函数（详见 [api-parameters.md](references/api-parameters#create_vault)），分别创建源端和目的端存储库：

**目的端存储库：**

- 传入目的端region和target_project_id
- 传入主机的名称ecs_name和主机ecs_id
- protect_type: `replication`
- consistent_level: `crash_consistent`
- 将返回的vault_id保存到server_conf的target_vault_id

**源端存储库：**

- 传入源端region和source_project_id
- 传入主机的名称ecs_name和主机ecs_id
- protect_type: `backup`
- consistent_level: `app_consistent`
- 将返回的vault_id保存到server_conf的source_vault_id

告知用户存储库已创建，源端和目的端vault_id的值是什么。

---

### 步骤11 创建源端主机CBR备份

传入步骤3获取的project_id和源端region_id，分别传入server_conf列表中每个主机的vault_id和name，多次调用`server.py`的
`create_checkpoints`函数（详见 [api-parameters.md](references/api-parameters#create_checkpoints)）为每个源端存储库执行备份。

将返回的checkpoint_id保存到server_conf列表中每个对应主机的source_checkpoint_id。

告知客户备份已创建，checkpoint_id的值是什么。

---

### 步骤12 等待CBR备份成功

持续调用`server.py`的`show_checkpoint`函数（详见 [api-parameters.md](references/api-parameters#show_checkpoint)
）查询备份创建进度，分别传入server_conf列表中每个主机的checkpoint_id，直到所有输出都为`available`后才进入下一步。

注意：函数输出的`status`必须是"available"后才能进入下一步，否则持续调用查询进度。

---

### 步骤13 创建主机备份跨区域复制

调用`server.py`的`copy_checkpoint`函数（详见 [api-parameters.md](references/api-parameters#copy_checkpoint)
），为每个存储库创建跨区域复制备份。

将返回的backup_id暂存（用于步骤15验证）。

---

### 步骤14 查询跨区域复制的备份创建是否完成

持续调用`server.py`的`list_backups`函数（详见 [api-parameters.md](references/api-parameters#list_backups)
）查询步骤14的跨区域复制创建的备份是否已经可用，分别传入server_conf列表中每个主机的target_vault_id，直到所有的status都输出为
`available`后才进入下一步。

将返回的backup_id保存到server_conf列表中每个对应主机的target_backup_id。

注意：函数输出的`status`必须是"available"后才能进入下一步，否则持续调用查询进度。

---

### 步骤15 创建整机镜像

调用`server.py`的`create_image`函数（详见 [api-parameters.md](references/api-parameters#create_image)
）创建目的端region整机镜像。分别传入server_conf中每个主机的target_backup_id、region和name。

将返回的job_id暂存（用于步骤17验证）。

---

### 步骤16 查询整机镜像创建进度

持续调用`server.py`的`show_job_progress`函数（详见 [api-parameters.md](references/api-parameters#show_job_progress)
）查询任务是否完成。分别传入步骤16获得的job_id。直到所有的status都输出为`SUCCESS`后才进入下一步。

注意：函数输出的`status`必须是"SUCCESS"后才能进入下一步，否则持续调用查询进度。
同时将返回的image_id保存到server_conf列表中每个对应主机的image_id。

---

### 步骤17 创建目的端主机

调用`server.py`的`create_server`函数（详见 [api-parameters.md](references/api-parameters#create_server)）创建目的端主机。

参数说明：

- vpc_id: 使用 server_conf 中的 target_vpc_id
- subnet_id: 使用 server_conf 中的 target_subnet_id

告知客户创建的ecs主机id是什么。

---

### 步骤18 删除临时资源

**⚠️ 执行前需用户确认，是否需要删除临时资源，如果不需要删除，则不执行步骤18，直接完成任务**

调用`server.py`的`delete_image`函数（详见 [api-parameters.md](references/api-parameters#delete_image)
）删除创建的镜像，分别传入server_conf列表中每个主机的image_id和目的端region。

再调用`server.py`的`delete_vault`函数（详见 [api-parameters.md](references/api-parameters#delete_vault)
）删除创建的存储库和备份，分别传入server_conf列表中每个主机的target_vault_id和source_vault_id，注意要把源端和目的端的存储库都删除。

---

### 完成

告知用户迁移任务已完成，列出：

- 目的端主机ID列表
- 各主机的源端/目的端region对应关系
