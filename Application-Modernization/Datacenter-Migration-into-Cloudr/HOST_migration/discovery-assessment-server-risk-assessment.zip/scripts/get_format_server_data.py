import argparse
import json
from typing import Optional


def load_ecs_instances(file_path: str) -> dict:
    """
    读取云资源 JSON 文件，解析并返回 ACS::ECS::Instance 实例列表。

    Args:
        file_path: JSON 文件的绝对或相对路径

    Returns:
        dict: 结构化结果，格式如下：
            成功: {"success": True,  "message": "成功读取 N 条 ECS 实例", "data": [...]}
            失败: {"success": False, "message": "错误描述",              "data": None}
    """
    # ---- 1. 文件存在性校验 ----
    try:
        with open(file_path, "r", encoding="utf-8-sig") as f:
            raw = f.read()
    except FileNotFoundError:
        return _fail(f"文件不存在: {file_path}")
    except PermissionError:
        return _fail(f"无权限读取文件: {file_path}")
    except OSError as e:
        return _fail(f"读取文件失败: {file_path}, 原因: {e}")

    # ---- 2. JSON 解析校验 ----
    try:
        data = json.loads(raw)
    except json.JSONDecodeError as e:
        return _fail(f"JSON 格式错误 (行{e.lineno} 列{e.colno}): {e.msg}")

    # ---- 3. 数据结构校验 ----
    if not isinstance(data, dict):
        return _fail(f"期望顶层为 dict，实际为 {type(data).__name__}")

    if "resources" not in data:
        return _fail("缺少 'resources' 字段")

    if not isinstance(data["resources"], dict):
        return _fail(f"'resources' 期望为 dict，实际为 {type(data['resources']).__name__}")

    # ---- 4. 目标资源类型校验 ----
    resource_key = "主机"
    if resource_key not in data["resources"]:
        available = list(data["resources"].keys())
        return _fail(
            f"未找到资源类型 '{resource_key}'，"
            f"当前可用类型: {available if available else '（无）'}"
        )

    instances = data["resources"][resource_key]

    if not isinstance(instances, list):
        return _fail(f"'{resource_key}' 期望为 list，实际为 {type(instances).__name__}")

    # ---- 5. 空数据警告（仍算成功，但提示 LLM 注意） ----
    count = len(instances)
    if count == 0:
        return {
            "success": True,
            "message": f"成功读取，但 '{resource_key}' 列表为空，共 0 条实例",
            "data": [],
        }

    return {
        "success": True,
        "message": f"成功读取 {count} 条 ECS 实例",
        "data": instances,
    }


def _fail(message: str) -> dict:
    """统一构造失败结果"""
    return {"success": False, "message": message, "data": None}


def main():
    # --- 命令行参数解析示例 ---
    parser = argparse.ArgumentParser(description='读取主机资源标准模型')
    parser.add_argument('file_path', help='标准模型文件')

    args = parser.parse_args()
    # --- 正常调用 ---
    result = load_ecs_instances(args.file_path)
    if result["success"]:
        print(result["message"])
        for i, ins in enumerate(result["data"], 1):
            print(f"  {ins}")
    else:
        print(f"错误: {result['message']}")

if __name__ == "__main__":
    main()
