import datetime
import json
import os
import argparse

from ecs_and_image_recommender_api import assess_server_specs_with_credential


def main():

    parser = argparse.ArgumentParser(description="华为云ECS规格批量推荐工具")
    parser.add_argument("ecs_instances", help="主机资源详细信息列表")
    parser.add_argument('credential_name', help='RDA-LITE凭证名称')
    parser.add_argument("region", help="华为云目标区域")
    parser.add_argument("source_platform", default="aliyun", choices=["aliyun", "huawei-cloud"])
    parser.add_argument("--priority_mode", default="price", choices=["performance", "price"])
    parser.add_argument("--output_dir", default=r"C:\DiscoveryData\SpecRecommend", help="保存文件目录")
    args = parser.parse_args()

    """
    主机规格和镜像评估主函数

    Args:
        ecs_instances: 主机资源信息列表（List[Dict]），每个字典应包含：
            - 资源ID: 实例ID
            - 地域: 地域信息
            - 规格/实例类型: 原始规格
            - 实例名称: 名称
            - 操作系统信息: 操作系统描述
            - CPU核心数: CPU数量
            - 内存: 内存大小（如"4GB"、"4096MB"）
        region: 华为云目标区域
        ak: 华为云Access Key
        sk: 华为云Secret Key
        source_platform: 源平台类型，默认"aliyun"
        priority_mode: 优先级模式，"price"或"performance"

    Returns:
        Dict，包含：
            - results: 评估结果列表
            - summary: 统计摘要
            - timestamp: 评估时间
    """
    ecs_instances = json.loads(args.ecs_instances)
    # 调用评估函数
    result = assess_server_specs_with_credential(
        ecs_instances=ecs_instances,
        region=args.region,
        credential_name=args.credential_name,
        source_platform=args.source_platform,
        priority_mode=args.priority_mode
    )

    # 保存结果
    os.makedirs(args.output_dir, exist_ok=True)
    current_time = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    output_file = os.path.join(args.output_dir, f"{args.source_platform}_server_spec_assessment_{current_time}.json")

    with open(output_file, "w", encoding="utf-8") as f:
        json.dump(result.to_dict(), f, ensure_ascii=False, indent=2)

    print(f"\n结果已保存到: {output_file}")


if __name__ == "__main__":
    main()