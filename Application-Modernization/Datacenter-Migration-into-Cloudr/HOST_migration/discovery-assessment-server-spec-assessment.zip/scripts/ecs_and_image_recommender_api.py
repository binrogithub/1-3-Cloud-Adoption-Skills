"""
华为云ECS规格和镜像批量推荐工具 (API版本)
根据主机资源信息列表，批量推荐华为云兼容的ECS规格和镜像

输入参数从文件路径改为直接传入主机资源信息列表
"""
from __future__ import annotations

import json
import re
import datetime
from typing import List, Dict, Optional, Set, Tuple
from dataclasses import dataclass, field, asdict
from enum import Enum

from huaweicloudsdkcore.http.http_config import HttpConfig

from list_credentials import CredentialService
from huaweicloudsdkims.v2.region.ims_region import ImsRegion
from huaweicloudsdkims.v2 import ImsClient
from huaweicloudsdkims.v2.model.list_images_request import ListImagesRequest
from huaweicloudsdkcore.auth.credentials import BasicCredentials
from huaweicloudsdkecs.v2 import EcsClient
from huaweicloudsdkecs.v2.region.ecs_region import EcsRegion
from huaweicloudsdkcore.exceptions import exceptions
from huaweicloudsdkecs.v2.model.list_flavors_request import ListFlavorsRequest

import sys
import os
import warnings
warnings.filterwarnings('ignore')

# 配置HTTP参数，禁用SSL验证
config = HttpConfig()
config.ignore_ssl_verification = True  # 关键：禁用SSL验证
config.timeout = 30  # 设置超时时间

# ============================================================
# 枚举定义
# ============================================================

class PriorityMode(Enum):
    """规格推荐优先级模式"""
    PRICE = "price"       # 价格优先
    PERFORMANCE = "performance"  # 性能优先


class SourcePlatform(Enum):
    """源平台类型"""
    ALIYUN = "aliyun"
    HUAWEI_CLOUD = "huawei-cloud"
    TENCENT = "tencent"
    AWS = "aws"
    AZURE = "azure"
    GOOGLE = "google"


class ImageMatchLevel(Enum):
    """镜像匹配级别"""
    VERSION_GTE = "version_gte"           # 版本大于等于
    SAME_MAJOR_VERSION = "same_major_version"  # 同主版本
    STRING_SIMILARITY = "string_similarity"    # 字符串相似度匹配
    NONE = ""


class OsType(Enum):
    """操作系统类型"""
    WINDOWS = "WINDOWS"
    LINUX = "LINUX"
    OTHER = "OTHER"


class ImageVersionCompareStatus(Enum):
    """镜像版本比较状态"""
    SAME_OR_NEWER_VERSION = "SAME_OR_NEWER_VERSION"
    SAME_MAJOR_VERSION = "SAME_MAJOR_VERSION"
    OLDER_VERSION = "OLDER_VERSION"


class HwFirmwareTypeEnum(Enum):
    """固件类型"""
    UEFI = "uefi"
    BIOS = "bios"


class ProcessStatus(Enum):
    """处理状态"""
    SUCCESS = "success"
    NO_MATCH = "no_match"
    FAILED = "failed"


# ============================================================
# 输入数据结构体
# ============================================================

@dataclass
class ServerInstanceInput:
    """
    主机实例输入数据结构

    Attributes:
        resource_id: 资源ID（实例ID）
        region: 地域
        instance_name: 实例名称
        flavor_type: 规格/实例类型
        cpu_cores: CPU核心数
        memory: 内存大小（支持格式：4GB、4096MB、4G、4096M）
        os_info: 操作系统信息（如：CentOS 7.9 64位）
        vendor: 供应商（huawei/vmware/other/aliyun等）
        performance_type: 性能类型（NORMAL/COMPUTINGV3/HIGHMEM），仅华为云使用
    """
    resource_id: str = ""
    region: str = ""
    instance_name: str = ""
    flavor_type: str = ""
    cpu_cores: int = 0
    memory: float = 0
    os_info: str = ""
    os_type : str = ""
    vendor: str = "aliyun"
    performance_type: str = ""

    @classmethod
    def from_dict(cls, data: Dict) -> ServerInstanceInput:
        """从字典创建实例（兼容多种字段名）"""
        return cls(
            resource_id=data.get("资源ID", data.get("resource_id", "")),
            region=data.get("地域", data.get("region", "")),
            instance_name=data.get("实例名称", data.get("instance_name", "")),
            flavor_type=data.get("规格/实例类型", data.get("flavor_type", "")),
            cpu_cores=int(data.get("CPU核心数", data.get("cpu_cores", 0))),
            memory=data.get("内存", data.get("memory_gb", 0)),
            os_info=data.get("操作系统信息", data.get("os_name", "")),
            os_type = data.get("操作系统类型", data.get("os_type", "")),
            vendor=data.get("vendor", data.get("供应商", "aliyun")),
            performance_type=data.get("performance_type", data.get("性能类型", ""))
        )

    def to_dict(self) -> Dict:
        """转换为字典"""
        return asdict(self)


@dataclass
class AssessmentRequest:
    """
    规格评估请求数据结构

    Attributes:
        instances: 主机实例列表
        region: 华为云目标区域
        credential_name: RDA凭证名称（与ak/sk二选一）
        ak: 华为云Access Key（与credential_name二选一）
        sk: 华为云Secret Key
        source_platform: 源平台类型
        priority_mode: 优先级模式
    """
    instances: List[ServerInstanceInput] = field(default_factory=list)
    region: str = ""
    credential_name: Optional[str] = None
    ak: Optional[str] = None
    sk: Optional[str] = None
    source_platform: SourcePlatform = SourcePlatform.ALIYUN
    priority_mode: PriorityMode = PriorityMode.PRICE

    def __post_init__(self):
        """类型转换"""
        if isinstance(self.source_platform, str):
            self.source_platform = SourcePlatform(self.source_platform)
        if isinstance(self.priority_mode, str):
            self.priority_mode = PriorityMode(self.priority_mode)

        # 字符串转ServerInstanceInput
        if self.instances and isinstance(self.instances[0], dict):
            self.instances = [ServerInstanceInput.from_dict(i) if isinstance(i, dict) else i for i in self.instances]

    @classmethod
    def from_dict(cls, data: Dict) -> AssessmentRequest:
        """从字典创建请求"""
        instances = data.get("instances", data.get("ecs_instances", []))
        return cls(
            instances=instances,
            region=data.get("region", ""),
            credential_name=data.get("credential_name"),
            ak=data.get("ak"),
            sk=data.get("sk"),
            source_platform=data.get("source_platform", "aliyun"),
            priority_mode=data.get("priority_mode", "price")
        )

    def to_dict(self) -> Dict:
        """转换为字典"""
        return {
            "instances": [i.to_dict() if hasattr(i, 'to_dict') else i for i in self.instances],
            "region": self.region,
            "credential_name": self.credential_name,
            "ak": self.ak,
            "sk": self.sk,
            "source_platform": self.source_platform.value if isinstance(self.source_platform, Enum) else self.source_platform,
            "priority_mode": self.priority_mode.value if isinstance(self.priority_mode, Enum) else self.priority_mode
        }


# ============================================================
# 输出数据结构体
# ============================================================

@dataclass
class RecommendedFlavor:
    """
    推荐的规格信息

    Attributes:
        name: 规格名称（如：ecs.c7.large）
        cpu_cores: CPU核心数
        memory_gb: 内存大小（GB）
    """
    name: str = ""
    cpu_cores: int = 0
    memory_gb: str = ""

    def to_dict(self) -> Dict:
        return asdict(self)


@dataclass
class RecommendedImage:
    """
    推荐的镜像信息

    Attributes:
        image_id: 镜像ID
        name: 镜像名称
        version: 镜像版本
        os_type: 操作系统类型
        match_level: 匹配级别
    """
    image_id: str = ""
    name: str = ""
    version: str = ""
    os_type: str = ""
    match_level: ImageMatchLevel = ImageMatchLevel.NONE

    @classmethod
    def from_image(cls, img: 'Image', match_level: str) -> RecommendedImage:
        """从Image对象创建"""
        return cls(
            image_id=img.imageId,
            name=img.name,
            version=img.version,
            os_type=img.osType,
            match_level=ImageMatchLevel(match_level) if match_level else ImageMatchLevel.NONE
        )

    def to_dict(self) -> Dict:
        return {
            "image_id": self.image_id,
            "name": self.name,
            "version": self.version,
            "os_type": self.os_type,
            "match_level": self.match_level.value if isinstance(self.match_level, Enum) else self.match_level
        }


@dataclass
class InstanceAssessmentResult:
    """
    单个主机实例的评估结果

    Attributes:
        resource_id: 资源ID
        region: 地域
        original_type: 原始类型
        name: 实例名称
        os_info: 操作系统信息
        source_flavor: 源规格
        source_cpu: 源CPU核心数
        source_memory: 源内存
        status: 处理状态
        recommended_flavor: 推荐的规格（成功时有值）
        recommended_image: 推荐的镜像
        error_message: 错误信息（失败时有值）
    """
    # 原始信息
    resource_id: str = ""
    region: str = ""
    original_type: str = ""
    name: str = ""
    os_info: str = ""
    source_flavor: str = ""
    source_cpu: int = 0
    source_memory: float = 0

    # 评估结果
    status: ProcessStatus = ProcessStatus.FAILED
    recommended_flavor: Optional[RecommendedFlavor] = None
    recommended_image: Optional[RecommendedImage] = None
    error_message: str = ""

    def __post_init__(self):
        """类型转换"""
        if isinstance(self.status, str):
            self.status = ProcessStatus(self.status)

    @classmethod
    def from_success(
        cls,
        resource_id: str,
        region: str,
        original_type: str,
        name: str,
        os_info: str,
        source_flavor: str,
        source_cpu: int,
        source_memory: float,
        recommended_flavor: Dict,
        recommended_image: Optional['Image'] = None,
        image_match_level: str = ""
    ) -> InstanceAssessmentResult:
        """创建成功结果"""
        return cls(
            resource_id=resource_id,
            region=region,
            original_type=original_type,
            name=name,
            os_info=os_info,
            source_flavor=source_flavor,
            source_cpu=source_cpu,
            source_memory=source_memory,
            status=ProcessStatus.SUCCESS,
            recommended_flavor=RecommendedFlavor(
                name=recommended_flavor.get("name", ""),
                cpu_cores=int(recommended_flavor.get("vcpus", 0)),
                memory_gb=f"{recommended_flavor.get('ram', 0) / 1024:.0f}GB"
            ),
            recommended_image=RecommendedImage.from_image(recommended_image, image_match_level) if recommended_image else None
        )

    @classmethod
    def from_no_match(
        cls,
        resource_id: str,
        region: str,
        original_type: str,
        name: str,
        os_info: str,
        source_flavor: str,
        source_cpu: int,
        source_memory: float,
        recommended_image: Optional['Image'] = None,
        image_match_level: str = ""
    ) -> InstanceAssessmentResult:
        """创建无匹配结果"""
        return cls(
            resource_id=resource_id,
            region=region,
            original_type=original_type,
            name=name,
            os_info=os_info,
            source_flavor=source_flavor,
            source_cpu=source_cpu,
            source_memory=source_memory,
            status=ProcessStatus.NO_MATCH,
            recommended_image=RecommendedImage.from_image(recommended_image, image_match_level) if recommended_image else None
        )

    @classmethod
    def from_failed(
        cls,
        resource_id: str,
        region: str,
        original_type: str,
        name: str,
        os_info: str,
        source_flavor: str,
        source_cpu: int,
        source_memory: float,
        error_message: str
    ) -> InstanceAssessmentResult:
        """创建失败结果"""
        return cls(
            resource_id=resource_id,
            region=region,
            original_type=original_type,
            name=name,
            os_info=os_info,
            source_flavor=source_flavor,
            source_cpu=source_cpu,
            source_memory=source_memory,
            status=ProcessStatus.FAILED,
            error_message=error_message
        )

    def to_dict(self) -> Dict:
        """转换为字典"""
        return {
            "resource_id": self.resource_id,
            "region": self.region,
            "original_type": self.original_type,
            "name": self.name,
            "os_info": self.os_info,
            "source_flavor": self.source_flavor,
            "source_cpu": self.source_cpu,
            "source_memory": self.source_memory,
            "status": self.status.value if isinstance(self.status, Enum) else self.status,
            "recommended_flavor": self.recommended_flavor.to_dict() if self.recommended_flavor else None,
            "recommended_image": self.recommended_image.to_dict() if self.recommended_image else None,
            "error_message": self.error_message
        }


@dataclass
class AssessmentSummary:
    """
    评估统计摘要

    Attributes:
        total: 总数
        success: 成功数
        no_match: 无匹配数
        failed: 失败数
    """
    total: int = 0
    success: int = 0
    no_match: int = 0
    failed: int = 0

    def to_dict(self) -> Dict:
        return asdict(self)

    @classmethod
    def from_results(cls, results: List[InstanceAssessmentResult]) -> AssessmentSummary:
        """从结果列表生成摘要"""
        return cls(
            total=len(results),
            success=len([r for r in results if r.status == ProcessStatus.SUCCESS]),
            no_match=len([r for r in results if r.status == ProcessStatus.NO_MATCH]),
            failed=len([r for r in results if r.status == ProcessStatus.FAILED])
        )


@dataclass
class AssessmentResponse:
    """
    规格评估响应数据结构

    Attributes:
        request_id: 请求ID
        timestamp: 评估时间戳
        region: 目标区域
        results: 单个实例评估结果列表
        summary: 统计摘要
    """
    request_id: str = ""
    timestamp: str = ""
    region: str = ""
    results: List[InstanceAssessmentResult] = field(default_factory=list)
    summary: Optional[AssessmentSummary] = None

    def __post_init__(self):
        """生成请求ID和时间戳"""
        if not self.request_id:
            import uuid
            self.request_id = str(uuid.uuid4())
        if not self.timestamp:
            self.timestamp = datetime.datetime.now().isoformat()
        if not self.summary and self.results:
            self.summary = AssessmentSummary.from_results(self.results)

    def to_dict(self) -> Dict:
        """转换为字典"""
        return {
            "request_id": self.request_id,
            "timestamp": self.timestamp,
            "region": self.region,
            "results": [r.to_dict() if hasattr(r, 'to_dict') else r for r in self.results],
            "summary": self.summary.to_dict() if self.summary else None
        }

    def to_json(self, indent: int = 2) -> str:
        """转换为JSON字符串"""
        return json.dumps(self.to_dict(), ensure_ascii=False, indent=indent)

# 尝试导入RDA客户端（如果可用）
try:
    mgc_edge_home = os.environ.get('MgC_EDGE_HOME', 'C:\\RDA')
    relay_path = os.path.join(mgc_edge_home, 'tools', 'plugins', 'relayagent', 'plugins', 'relayagent', 'bin', 'packages', 'relay-core', 'src')
    if str(relay_path) not in sys.path:
        sys.path.insert(0, str(relay_path))
    from relay_core.infrastructure.external.rda_client.client import RdaClient
    HAS_RDA_CLIENT = True
except ImportError:
    HAS_RDA_CLIENT = False


DEFAULT_MGC_EDGE_HOME = r'C:\RDA' if sys.platform == 'win32' else '/opt/cloud/RDA'
RDA_CONFIG_PATH = 'tools/plugins/relayagent/plugins/relayagent/config/rda-config.yaml'


def _get_mgc_edge_home() -> str:
    return os.environ.get('MgC_EDGE_HOME', DEFAULT_MGC_EDGE_HOME)


def _load_rda_config() -> dict:
    config_path = os.path.join(_get_mgc_edge_home(), RDA_CONFIG_PATH)
    if not os.path.exists(config_path):
        return {}
    try:
        with open(config_path, 'r', encoding='utf-8') as f:
            import yaml
            config = yaml.safe_load(f)
            return config if isinstance(config, dict) else {}
    except:
        return {}

@dataclass
class Image:
    """镜像数据结构"""
    imageId: str
    name: str
    version: str
    osType: str = ""
    platform: str = ""
    min_disk: int = 40
    is_offshelved: bool = False
    hw_firmware_type: HwFirmwareTypeEnum = HwFirmwareTypeEnum.UEFI


# ============================================================
# 核心工具函数
# ============================================================

def parse_memory_to_mb(memory_str: float) -> int:
    """解析内存字符串为MB"""
    if not memory_str:
        return 0
    try:
        return int(float(memory_str) * 1024)
    except ValueError:
        return 0


def extract_flavor_family(flavor_name: str) -> str:
    """从规格名称提取规格族"""
    if not flavor_name:
        return ""
    if flavor_name.startswith("ecs."):
        flavor_name = flavor_name[4:]
    if "." in flavor_name:
        return flavor_name.split(".")[0]
    return flavor_name


def extract_os_version(os_info: str) -> Tuple[str, str]:
    """从操作系统信息提取系统名称和版本"""
    match = re.match(r"(.+?)\s+(\d+(?:\.\d+)*)\s*.*", os_info)
    if match:
        return match.group(1).strip(), match.group(2).strip()
    return os_info, "0.0"


def parse_version(version: str) -> Tuple[int, ...]:
    """解析版本号为元组"""
    parts = re.findall(r"\d+", version)
    return tuple(int(p) for p in parts[:3]) if parts else (0, 0, 0)


def get_major_version(version: str) -> int:
    """获取主版本号"""
    parsed = parse_version(version)
    return parsed[0] if parsed else 0


def compare_versions(v1: str, v2: str) -> int:
    """比较两个版本号"""
    ver1 = parse_version(v1)
    ver2 = parse_version(v2)
    if ver1 > ver2:
        return 1
    elif ver1 < ver2:
        return -1
    return 0


def extract_version_from_name(name: str) -> str:
    """从镜像名称中提取版本号"""
    patterns = [r"(\d+)\.(\d+)\.(\d+)", r"(\d+)\.(\d+)", r"(\d+)"]
    for pattern in patterns:
        match = re.search(pattern, name)
        if match:
            groups = match.groups()
            return groups[0] if len(groups) == 1 else ".".join(groups)
    return "0.0.0"


GB_TO_B = 1024 * 1024 * 1024
MATCHER_MAX_LENGTH = 1000 * 1000
DEFAULT_MIN_DISK_CAPACITY = 40
PATTERN_32_BIT = re.compile(r"^.{0,255}32(-|_| )?(bit|位).{0,255}$")


def _num_sim(num1: int, num2: int, weight: float = 1.1) -> float:
    """
    计算两个数字的相似度
    与Java的 numSim 方法一致
    """
    if num1 == num2:
        return 1.0
    abs_diff = abs(num1 - num2)
    max_val = max(abs(num1), abs(num2))
    if max_val == 0:
        return 1.0
    return max(0.0, weight - abs_diff / max_val)


def _str_simi(s1: str, s2: str, mod: int = 0) -> float:
    """
    计算两个字符串的相似度
    与Java的 simiCalc 方法一致
    mod=1 时（含有Windows），特殊处理
    """
    if not s1 or not s2:
        return 0.0

    s1_lower = s1.lower()
    s2_lower = s2.lower()

    if s1_lower == s2_lower:
        return 1.0

    # Windows模式特殊处理
    if mod == 1:
        if s1_lower == s2_lower:
            return 1.0
        # 检查是否是 "windows" vs "server" 这样的组合
        if ("windows" in s1_lower and "server" in s2_lower) or \
                ("server" in s1_lower and "windows" in s2_lower):
            return 0.9

    # 使用编辑距离计算相似度
    len1, len2 = len(s1_lower), len(s2_lower)
    max_len = max(len1, len2)

    if max_len == 0:
        return 1.0

    # 构建DP矩阵计算编辑距离
    dp = [[0] * (len2 + 1) for _ in range(len1 + 1)]

    for i in range(len1 + 1):
        dp[i][0] = i
    for j in range(len2 + 1):
        dp[0][j] = j

    for i in range(1, len1 + 1):
        for j in range(1, len2 + 1):
            if s1_lower[i - 1] == s2_lower[j - 1]:
                dp[i][j] = dp[i - 1][j - 1]
            else:
                dp[i][j] = min(dp[i - 1][j], dp[i][j - 1], dp[i - 1][j - 1]) + 1

    edit_distance = dp[len1][len2]
    return 1.0 - edit_distance / max_len


def similarity(str1: str, str2: str) -> float:
    """
    计算两个字符串的相似度
    与Java的 StringSimilarityUtils.similarity 方法一致
    算法：基于词项的相似度矩阵计算（双向匹配）
    """
    if not str1 or not str2:
        return 0.0

    # 预处理：去除-、转小写、去除edition
    a = str1.replace("-", " ").lower().replace("edition", "")
    b = str2.replace("-", " ").lower().replace("edition", "")

    # 分词：按空白符和下划线分割
    words_a = re.split(r'[\s_-]+', a)
    words_b = re.split(r'[\s_-]+', b)

    # 构建词频Map
    word_map_a: Dict[str, int] = {}
    for word in words_a:
        if word:
            word_map_a[word] = word_map_a.get(word, 0) + 1

    word_map_b: Dict[str, int] = {}
    for word in words_b:
        if word:
            word_map_b[word] = word_map_b.get(word, 0) + 1

    if not word_map_a or not word_map_b:
        return 0.0

    # 判断是否含有Windows（mod=1时特殊处理）
    has_windows = "windows" in word_map_a or "windows" in word_map_b
    mod = 1 if has_windows else 0

    # 构建相似度矩阵
    matrix: List[List[float]] = [[0.0] * len(word_map_b) for _ in range(len(word_map_a))]

    result_ab = 0.0
    entries_a = list(word_map_a.items())
    entries_b = list(word_map_b.items())

    for i, (word_a, count_a) in enumerate(entries_a):
        temp = 0.0
        for j, (word_b, count_b) in enumerate(entries_b):
            repeat_sim = _num_sim(count_a, count_b, 1.1)
            t = _str_simi(word_a, word_b, mod) * repeat_sim
            matrix[i][j] = t
            if t > temp:
                temp = t
        result_ab += temp

    # 计算resultBA
    result_ba = 0.0
    for j in range(len(entries_b)):
        temp = 0.0
        for i in range(len(entries_a)):
            if matrix[i][j] > temp:
                temp = matrix[i][j]
        result_ba += temp

    return (result_ab + result_ba) / (len(word_map_a) + len(word_map_b))


def check_source_image(source_image_info: str) -> None:
    """校验源端镜像信息"""
    if not source_image_info:
        raise ValueError("Sms.00070005: 评估镜像失败，缺少操作系统信息")

    if PATTERN_32_BIT.match(source_image_info):
        raise ValueError("Sms.00070047: 公共镜像不支持32位操作系统")

    if "other" in source_image_info.lower():
        raise ValueError("Sms.00070048: 源端操作系统不明确，请自行选择镜像")


def filter_images(images: List[Image], os_type: OsType) -> List[Image]:
    """过滤镜像列表"""
    images = [img for img in images if not img.is_offshelved]
    if not images:
        raise ValueError("Sms.00070019: 镜像列表为空")

    if os_type == OsType.WINDOWS:
        windows_images = [
            img for img in images
            if img.osType.upper() == OsType.WINDOWS.name
            and "ARM" not in img.name
        ]
        if not windows_images:
            raise ValueError("Sms.00070017: 未找到Windows镜像")
        return windows_images

    linux_images = [
            img for img in images
            if img.osType.upper() == OsType.LINUX.name
            and "ARM" not in img.name
        ]
    if not linux_images:
        raise ValueError("Sms.00070018: 未找到Linux镜像")
    return linux_images


def get_os_type(os_info: str) -> OsType:
    """从OS信息获取操作系统类型"""
    os_info_lower = os_info.lower()
    if "windows" in os_info_lower:
        return OsType.WINDOWS
    elif "linux" in os_info_lower or "centos" in os_info_lower or "ubuntu" in os_info_lower or \
         "debian" in os_info_lower or "rocky" in os_info_lower or "anolis" in os_info_lower or \
         "alibaba" in os_info_lower:
        return OsType.LINUX
    return OsType.OTHER


def compare_image_version(os_info: str, source_image: Image) -> ImageVersionCompareStatus:
    """比较镜像版本号"""
    image_info = os_info.lower()

    if not source_image.version:
        return ImageVersionCompareStatus.OLDER_VERSION

    source_image_info = source_image.version.lower()
    platform = source_image.platform.lower()

    if source_image.osType.upper() == "WINDOWS":
        platform += " server"

    image = re.sub(r'(\d)_(?=\d)', r'\1.', image_info.replace("_", " "))
    source_image_info = source_image_info.replace("_", " ")

    if len(image) > MATCHER_MAX_LENGTH or len(source_image_info) > MATCHER_MAX_LENGTH:
        raise ValueError("Sms.00000004: 信息过长")

    regex = re.escape(platform) + r"\s+(\d{1,100}(?:\.\d{1,100}){0,100})"

    try:
        image_match = re.search(regex, image)
        source_image_match = re.search(regex, source_image_info)
    except re.error:
        return ImageVersionCompareStatus.OLDER_VERSION

    image_version = []
    source_image_version = []

    if image_match:
        image_version = [int(x) for x in image_match.group(1).split(".")]

    if source_image_match:
        source_image_version = [int(x) for x in source_image_match.group(1).split(".")]

    if not image_version or not source_image_version:
        return ImageVersionCompareStatus.OLDER_VERSION

    min_size = min(2, min(len(image_version), len(source_image_version)))

    if image_version[0] != source_image_version[0]:
        return (ImageVersionCompareStatus.SAME_OR_NEWER_VERSION
                if source_image_version[0] > image_version[0]
                else ImageVersionCompareStatus.OLDER_VERSION)

    for version_index in range(1, min_size):
        if image_version[version_index] != source_image_version[version_index]:
            return (ImageVersionCompareStatus.SAME_OR_NEWER_VERSION
                    if source_image_version[version_index] > image_version[version_index]
                    else ImageVersionCompareStatus.SAME_MAJOR_VERSION)

    return (ImageVersionCompareStatus.SAME_OR_NEWER_VERSION
            if min(2, len(source_image_version)) >= min(2, len(image_version))
            else ImageVersionCompareStatus.SAME_MAJOR_VERSION)


def get_recommend_image_by_similarity(image_list: List[Image], os_info: str) -> Optional[Image]:
    """根据字符串相似度算法计算推荐镜像"""
    recommend_image = None
    recommend_image_second_priority = None
    similarity1 = similarity2 = similarity3 = 0.0
    recommend_image_list = []

    for source_image in image_list:
        temp = similarity(os_info, source_image.name)
        compare_status = compare_image_version(os_info, source_image)

        if compare_status == ImageVersionCompareStatus.SAME_OR_NEWER_VERSION:
            recommend_image_list.append((temp, source_image))
        elif (not recommend_image_second_priority and
              compare_status == ImageVersionCompareStatus.SAME_MAJOR_VERSION):
            recommend_image_second_priority = source_image

        if temp > similarity1:
            similarity3 = similarity2
            similarity2 = similarity1
            similarity1 = temp
            recommend_image = source_image
            continue  # 跳过剩余相似度比较

        if temp > similarity2:
            similarity3 = similarity2
            similarity2 = temp
            continue  # 跳过剩余相似度比较

        if temp > similarity3:
            similarity3 = temp

    if recommend_image_list:
        # 获取列表的最后一个元素（与Java逻辑一致，不排序）
        recommend_image = recommend_image_list[-1][1]
    elif recommend_image_second_priority:
        recommend_image = recommend_image_second_priority

    return recommend_image


# ============================================================
# 规格映射和推荐逻辑
# ============================================================

HUAWEI = "huawei、huawei_cloud"
OTHER = ["ALIYUN", "AWS", "AZURE"]
VMWARE = ["VMWARE"]
BYTE_TO_GB = 1024 * 1024 * 1024

SPEC_ASSESS_OPERATION_LIST = {
    "sort_by_price_list": ["x1", "x1e", "s6", "s3", "s7", "c3", "c6", "c7"],
    "sort_by_performance_list": ["x1e", "c7", "ac7", "c6", "c6s", "c3", "x1", "s7", "s6", "s3"],
    "vmware_flavor_type_list_ratio_h25_when_cpu_l8": ["x1", "x1e", "s6", "s7n", "c6s", "c6", "c7"],
    "vmware_flavor_type_list_ratio_h25_when_cpu_h8": ["x1", "x1e", "c6s", "c6", "c7"],
    "vmware_flavor_type_list_ratio_between_125_and_25": ["x1", "x1e", "m6", "m7n"],
    "vmware_flavor_type_list_ratio_l125": ["e3", "e7", "m2", "m3", "m6", "am7", "m7"],
    "unsupported_hw_spec_type_set": ["t7", "at7"]
}

PLATFORM_FLAVOR_MAPPING = [
    {"hw": "c7", "aliyun": "g8a/g8i/g8ae/g8y/g7se/g7a/g7/g7t/g7ne/g7nex/g7h/g6h/g6r/g6a/g6t/g6e/g6/g5ne/c7/c8a/c8i/c8ae/c8y/c7re/c7se/c7nex/c7a/c7t/c6r/c6a/c6t/c6e/c6/ic5/u1/n1/n2", "tencent": "SA5/SA4/SA3/S5se/C2/C3/C4/C5/C6/CN3", "aws": "m5ad/c7a/c7i/c7g/c7gd/c7gn/c6g/c6gd/c6gn/c6i/c6id/c6in/c6a/c5/c5n/c5a/c5ad/c4", "azure": "Dv2/Dsv2/Dv3/Dsv3/Av2/A0-A7", "google": "c3d/c3"},
    {"hw": "c7h", "aliyun": "g8a/g8i/g8ae/g8y/g7se/g7a/g7/g7t/g7ne/g7nex/g7h/g6h/g6r/g6a/g6t/g6e/g6/g5ne/c8a/c8i/c8ae/c8y/c7re/c7se/c7nex/c7a/c7/c7t/c6r/c6a/c6t/c6e/c6/ic5/n1/n2", "tencent": "SA5/SA4/SA3/S5se/C2/C3/C4/C5/C6/CN3", "aws": "c7g/c7gn/c6g/c6gn/c6i/c6in/c6a/c5/c5n/c5a/c4", "azure": "Dv2/Dsv2/Dv3/Dsv3/Av2/A0-A7", "google": "c3d/c3"},
    {"hw": "ac7", "aliyun": "g8a/g8i/g8ae/g8y/g7se/g7a/g7/g7t/g7ne/g7nex/g7h/g6h/g6r/g6a/g6t/g6e/g6/g5ne/c8a/c8i/c8ae/c8y/c7re/c7se/c7nex/c7a/c7/c7t/c6r/c6a/c6t/c6e/c6/ic5/n1/n2", "tencent": "SA5/SA4/SA3/S5se/C2/C3/C4/C5/C6/CN3", "aws": "c7g/c7gn/c6g/c6gn/c6i/c6in/c6a/c5/c5n/c5a/c4", "azure": "Dv2/Dsv2/Dv3/Dsv3/Av2/A0-A7", "google": "c3d/c3"},
    {"hw": "c6s", "aliyun": "g8a/g8i/g8ae/g8y/g7se/g7a/g7/g7t/g7ne/g7nex/g7h/g6h/g6r/g6a/g6t/g6e/g6/g5ne/c6/c8a/c8i/c8ae/c8y/c7re/c7se/c7nex/c7a/c7/c7t/c6r/c6a/c6t/c6e/ic5/g5/c5/sn2ne/sn1ne/u1/n1/n2", "tencent": "C2/C3/C4/C5/C6/CN3", "aws": "m5ad/c7a/c7i/c7g/c7gd/c7gn/c6g/c6gd/c6gn/c6i/c6id/c6in/c6a/c5/c5n/c5a/c5ad/c4", "azure": "Dv2/Dsv2/Dv3/Dsv3/Av2/A0-A7", "google": "c3d/c3"},
    {"hw": "c6", "aliyun": "g8a/g8i/g8ae/g8y/g7se/g7a/g7/g7t/g7ne/g7nex/g7h/g6h/g6r/g6a/g6t/g6e/g6/g5ne/c6/c8a/c8i/c8ae/c8y/c7re/c7se/c7nex/c7a/c7/c7t/c6r/c6a/c6t/c6e/ic5/g5/c5/sn2ne/sn1ne/u1/n1/n2", "tencent": "C2/C3/C4/C5/C6/CN3", "aws": "m5ad/c7a/c7i/c7g/c7gd/c7gn/c6g/c6gd/c6gn/c6i/c6id/c6in/c6a/c5/c5n/c5a/c5ad/c4", "azure": "Dv2/Dsv2/Dv3/Dsv3/Av2/A0-A7", "google": "c3d/c3"},
    {"hw": "c3", "aliyun": "g8a/g8i/g8ae/g8y/g7se/g7a/g7/g7t/g7ne/g7nex/g7h/g6h/g6r/g6a/g6t/g6e/g6/g5ne/c3/c8a/c8i/c8ae/c8y/c7re/c7se/c7nex/c7a/c7/c7t/c6r/c6a/c6t/c6e/c6/ic5/g5/c5/sn2ne/sn1ne/n1/n2", "tencent": "C2/C3/C4/C5/C6/CN3", "aws": "m5ad/c7a/c7i/c7g/c7gd/c7gn/c6g/c6gd/c6gn/c6i/c6id/c6in/c6a/c5/c5n/c5a/c5ad/c4", "azure": "Dv2/Dsv2/Dv3/Dsv3/Av2/A0-A7", "google": "c3d/c3"},
    {"hw": "c3ne", "aliyun": "g8a/g8i/g8ae/g8y/g7se/g7a/g7/g7t/g7ne/g7nex/g7h/g6h/g6r/g6a/g6t/g6e/g6/g5ne/c7/c8a/c8i/c8ae/c8y/c7re/c7se/c7nex/c7a/c7t/c6r/c6a/c6t/c6e/c6/ic5/g5/c5/sn2ne/sn1ne/u1/n1/n2", "tencent": "C2/C3/C4/C5/C6/CN3", "aws": "m5ad/c7a/c7i/c7g/c7gd/c7gn/c6g/c6gd/c6gn/c6i/c6id/c6in/c6a/c5/c5n/c5a/c5ad/c4", "azure": "Dv2/Dsv2/Dv3/Dsv3/Av2/A0-A7", "google": "c3d/c3"},
    {"hw": "x1", "aliyun": "s6/xn4/n4/mn4/u1/n1/n2/e/t5", "tencent": "S1/S2/S3/S4/S5/S6/SA5/SA4/SA3/SA2/SA1/S5se/SN3ne/S2ne/SR1", "aws": "m7g/m7gd/m7i/m7i-flex/m7a/m6g/m6i/m6id/m6in/m6idn/m6gd/m6a/m5/m5d/m5dn/m5n/m5zn/m5a/m5ad/m4/mac1/mac2/mac2-m2/mac2-m2pro/t4g/t3/t2/t3a", "azure": "", "google": "n2/n2d/t2d/t2a/n1/e2"},
    {"hw": "x1e", "aliyun": "g8a/g8i/g8ae/g8y/g7se/g7a/g7/g7t/g7ne/g7nex/g7h/g6h/g6r/g6a/g6t/g6e/g6/g5ne/s6/xn4/n4/mn4/u1/n1/n2/c7/c8a/c8i/c8ae/c8y/c7re/c7se/c7nex/c7a/c7t/c6r/c6a/c6t/c6e/c6/c5/ic5", "tencent": "S1/S2/S3/S4/S5/S6/SA5/SA4/SA3/SA2/SA1/S5se/SN3ne/S2ne/SR1", "aws": "m7g/m7gd/m7i/m7i-flex/m7a/m6g/m6i/m6id/m6in/m6idn/m6gd/m6a/m5/m5d/m5dn/m5n/m5zn/m5a/m5ad/m4/mac1/mac2/mac2-m2/mac2-m2pro/t4g", "azure": "", "google": "n2/n2d/t2d/t2a/n1/e2"},
    {"hw": "s7", "aliyun": "s6/xn4/n4/mn4/u1/n1/n2", "tencent": "S1/S2/S3/S4/S5/S6/SA5/SA4/SA3/SA2/SA1/S5se/SN3ne/S2ne/SR1", "aws": "m7g/m7gd/m7i/m7i-flex/m7a/m6g/m6i/m6id/m6in/m6idn/m6gd/m6a/m5/m5d/m5dn/m5n/m5zn/m5a/m5ad/m4/mac1/mac2/mac2-m2/mac2-m2pro/t4g", "azure": "", "google": "n2/n2d/t2d/t2a/n1/e2"},
    {"hw": "s6", "aliyun": "s6/xn4/n4/mn4/u1/n1/n2", "tencent": "S1/S2/S3/S4/S5/S6/SA5/SA4/SA3/SA2/SA1/S5se/SN3ne/S2ne/SR1", "aws": "m7g/m7i/m7i-flex/m7a/m6g/m6i/m6in/m6a/m5/m5n/m5zn/m5a/m4/t4g", "azure": "", "google": "n2/n2d/t2d/t2a/n1/e2"},
    {"hw": "s3", "aliyun": "s6/xn4/n4/mn4/u1/n1/n2", "tencent": "S1/S2/S3/S4/S5/S6/SA5/SA4/SA3/SA2/SA1/S5se/SN3ne/S2ne/SR1", "aws": "m7g/m7i/m7i-flex/m7a/m6g/m6i/m6in/m6a/m5/m5n/m5zn/m5a/m4/t4g", "azure": "", "google": "n2/n2d/t2d/t2a/n1/e2"},
    {"hw": "s2", "aliyun": "s6/xn4/n4/mn4/u1/n1/n2", "tencent": "S1/S2/S3/S4/S5/S6/SA5/SA4/SA3/SA2/SA1/S5se/SN3ne/S2ne/SR1", "aws": "m7g/m7i/m7i-flex/m7a/m6g/m6i/m6in/m6a/m5/m5n/m5zn/m5a/m4/t4g", "azure": "", "google": "n2/n2d/t2d/t2a/n1/e2"},
    {"hw": "sn3", "aliyun": "s6/xn4/n4/mn4/u1/n1/n2", "tencent": "S1/S2/S3/S4/S5/S6/SA5/SA4/SA3/SA2/SA1/S5se/SN3ne/S2ne/SR1", "aws": "m7g/m7i/m7i-flex/m7a/m6g/m6i/m6in/m6a/m5/m5n/m5zn/m5a/m4", "azure": "", "google": "n2/n2d/t2d/t2a/n1/e2"},
    {"hw": "s7n", "aliyun": "s6/xn4/n4/mn4/u1/n1/n2", "tencent": "S1/S2/S3/S4/S5/S6/SA5/SA4/SA3/SA2/SA1/S5se/SN3ne/S2ne/SR1", "aws": "m7g/m7i/m7i-flex/m7a/m6g/m6i/m6in/m6a/m5/m5n/m5zn/m5a/m4", "azure": "", "google": "n2/n2d/t2d/t2a/n1/e2"},
    {"hw": "m7", "aliyun": "r8a/r8i/r8ae/r8y/re7p/r7p/r7se/r7a/r7/r7t/r7p/re6p/r6a/r6e/r6/re6/r5/se1ne/se1/e4/e3", "tencent": "M1/M2/M3/M4/M5/M6/MA2/MA5/M6p/M6mp/M6ce/MA3", "aws": "r7g/r7a/r7i/r7iz/r6g/r6i/r6in/r6a/r5/r5n/r5b/r5a/r4/x2gd/x2idn/x2iedn/x2iezn/x1/x1e/u-3tb1/z1d", "azure": "Esv3/Ev3/Gs/G", "google": "m1/m2/m3"},
    {"hw": "am7", "aliyun": "r8a/r8i/r8ae/r8y/re7p/r7p/r7se/r7a/r7/r7t/r7p/re6p/r6a/r6e/r6/re6/r5/se1ne/se1/e4/e3", "tencent": "M1/M2/M3/M4/M5/M6/MA2/MA5/M6p/M6mp/M6ce/MA3", "aws": "r7g/r7a/r7i/r7iz/r6g/r6i/r6in/r6a/r5/r5n/r5b/r5a/r4/x2gd/x2idn/x2iedn/x2iezn/x1/x1e/u-3tb1/z1d", "azure": "Esv3/Ev3/Gs/G", "google": "m1/m2/m3"},
    {"hw": "m6", "aliyun": "r8a/r8i/r8ae/r8y/re7p/r7p/r7se/r7a/r7/r7t/r7p/re6p/r6a/r6e/r6/re6/r5/se1ne/se1/e4/e3", "tencent": "M1/M2/M3/M4/M5/M6/MA2/MA5/M6p/M6mp/M6ce/MA3", "aws": "r7g/r7a/r7i/r7iz/r6g/r6i/r6in/r6a/r5/r5n/r5b/r5a/r4/x2gd/x2idn/x2iedn/x2iezn/x1/x1e/u-3tb1/z1d", "azure": "Esv3/Ev3/Gs/G", "google": "m1/m2/m3"},
    {"hw": "m3", "aliyun": "r8a/r8i/r8ae/r8y/re7p/r7p/r7se/r7a/r7/r7t/r7p/re6p/r6a/r6e/r6/re6/r5/se1ne/se1/e4/e3", "tencent": "M1/M2/M3/M4/M5/M6/MA2/MA5/M6p/M6mp/M6ce/MA3", "aws": "r7g/r7a/r7i/r7iz/r6g/r6i/r6in/r6a/r5/r5n/r5b/r5a/r4/x2gd/x2idn/x2iedn/x2iezn/x1/x1e/u-3tb1/z1d", "azure": "Esv3/Ev3/Gs/G", "google": "m1/m2/m3"},
    {"hw": "m3ne", "aliyun": "r8a/r8i/r8ae/r8y/re7p/r7p/r7se/r7a/r7/r7t/r7p/re6p/r6a/r6e/r6/re6/r5/se1ne/se1/e4/e3", "tencent": "M1/M2/M3/M4/M5/M6/MA2/MA5/M6p/M6mp/M6ce/MA3", "aws": "r7g/r7a/r7i/r7iz/r6g/r6i/r6in/r6a/r5/r5n/r5b/r5a/r4/x2gd/x2idn/x2iedn/x2iezn/x1/x1e/u-3tb1/z1d", "azure": "Esv3/Ev3/Gs/G", "google": "m1/m2/m3"},
    {"hw": "e3", "aliyun": "r8ae/re7p/r7se/r7t/re4/re4e", "tencent": "M1/M2/M3/M4/M5/M6/MA2/M6p/M6mp/M6ce/MA3", "aws": "r8g/r7g/r7iz/r6g/r6i/r6in/r6a/r5/r5n/r5b/r5a/r4/x2gd/x2idn/x2iedn/x2iezn/x1/x1e/u-3tb1/z1d/u-6tb1", "azure": "M/Mv2", "google": "m2/m3/z3"},
    {"hw": "e6", "aliyun": "r8ae/re7p/r7se/r7t/re4/re4e", "tencent": "M1/M2/M3/M4/M5/M6/MA2/M6p/M6mp/M6ce/MA3", "aws": "r8g/r7g/r7iz/r6g/r6i/r6in/r6a/r5/r5n/r5b/r5a/r4/x2gd/x2idn/x2iedn/x2iezn/x1/x1e/u-3tb1/z1d/u-6tb1", "azure": "M/Mv2", "google": "m2/m3/z3"},
    {"hw": "e7", "aliyun": "r8ae/re7p/r7se/r7t/re4/re4e", "tencent": "M1/M2/M3/M4/M5/M6/MA2/M6p/M6mp/M6ce/MA3", "aws": "r8g/r7a/r7i/r7iz/r6g/r6i/r6in/r6a/r5/r5n/r5b/r5a/r4/x2gd/x2idn/x2iedn/x2iezn/x1/x1e/u-3tb1/z1d/u-6tb1", "azure": "M/Mv2", "google": "m1/m2/m3/z3"},
    {"hw": "h3", "aliyun": "hfc8i/hfc7/hfc6/hfg8i/hfg7/hfg6/hfr6/hfr8i/hfr7/hfr6/hfc5/hfg5/hfc5/c4/cm4/ce4/scch5/scch5s/sccc7/sccg7", "tencent": "C2/C3/C4/C5/C6/CN3", "aws": "hpc7g/hpc7a/hpc6id/hpc6a", "azure": "F/Fs/Fsv2", "google": "h3/c2/c2d"},
    {"hw": "hc2", "aliyun": "hfc8i/hfc7/hfc6/hfg8i/hfg7/hfg6/hfr6/hfr8i/hfr7/hfr6/hfc5/hfg5/hfc5/c4/cm4/ce4/scch5/scch5s/sccc7/sccg7", "tencent": "C2/C3/C4/C5/C6/CN3", "aws": "hpc7g/hpc7a/hpc6id/hpc6a", "azure": "F/Fs/Fsv2", "google": "h3/c2/c2d"},
    {"hw": "hi3", "aliyun": "", "tencent": "", "aws": "hpc7g/hpc7a/hpc6id/hpc6a", "azure": "H/A8-11", "google": ""},
    {"hw": "d7", "aliyun": "d1/d1ne/d2/d2c/d2s/d3/d3c/d3s", "tencent": "D2/D3", "aws": "d2/d3/d3en", "azure": "", "google": ""},
    {"hw": "d6", "aliyun": "d1/d1ne/d2/d2c/d2s/d3/d3c/d3s", "tencent": "D2/D3", "aws": "d2/d3/d3en", "azure": "", "google": ""},
    {"hw": "d3", "aliyun": "d1/d1ne/d2/d2c/d2s/d3/d3c/d3s", "tencent": "D2/D3", "aws": "d2/d3/d3en", "azure": "", "google": ""},
    {"hw": "d2", "aliyun": "d1/d1ne/d2/d2c/d2s/d3/d3c/d3s", "tencent": "D2/D3", "aws": "d2/d3/d3en", "azure": "", "google": ""},
    {"hw": "i7", "aliyun": "i4/i4g/i4r/i4p/i3g/i3/i2/i2g/i2ne/i2gne", "tencent": "IT5/IT3/I3", "aws": "i4g/im4gn/Is4gen/i4i/i3/i3en/h1/d2/d3/d3en/h1", "azure": "Ls", "google": ""},
    {"hw": "i3", "aliyun": "i4/i4g/i4r/i4p/i3g/i3/i2/i2g/i2ne/i2gne", "tencent": "IT5/IT3/I3", "aws": "i4g/Im4gn/Is4gen/i4i/i3/i3en/h1/d2/d3/d3en/h1", "azure": "Ls", "google": ""},
    {"hw": "ir7", "aliyun": "i4/i4g/i4r/i4p/i3g/i3/i2/i2g/i2ne/i2gne/i1", "tencent": "IT5/IT3/I3", "aws": "i4g/Im4gn/Is4gen/i4i/i3/i3en/h1/d2/d3/d3en/h1", "azure": "", "google": ""},
    {"hw": "ir3", "aliyun": "i4/i4g/i4r/i4p/i3g/i3/i2/i2g/i2ne/i2gne/i1", "tencent": "IT5/IT3/I3", "aws": "i4g/Im4gn/Is4gen/i4i/i3/i3en/h1/d2/d3/d3en/h1", "azure": "", "google": ""},
    {"hw": "p2v", "aliyun": "ga1/gn6i/gn7e/gn7i/gn7s/gn7/gn7r/gn6i/gn6e/gn6v/gn5/gn5i/sgn7i/vgn7i/vgn6i/ebmgn7ix/gn6v/gn6e/ebmgn6v/ebmgn6ia", "tencent": "PNV4/GT4/GN10Xp/GN7/GN7vi/PTX1/PNV4ne/GI3X/GN10X/GN8/GN6/GN6S", "aws": "p5/p4/p3/p2/dl1/trn1/imf2/inf1/vt1", "azure": "", "google": "a2/a3/g2"},
    {"hw": "g5", "aliyun": "ga1/gn6i/gn7e/gn7i/gn7s/gn7/gn7r/gn6i/gn6e/gn6v/gn5/gn5i/sgn7i/vgn7i/vgn6i/ebmgn7ix/gn6v/gn6e/ebmgn6v/ebmgn6ia", "tencent": "GA3/GNV4v/GNV4/GN7vw/GI1", "aws": "g5g/g5/g4dn/g4ad/g3", "azure": "", "google": "g2"},
    {"hw": "pi2", "aliyun": "gn6i/gn7e/gn7i/gn7s/gn7/gn7r/gn6i/gn6e/gn6v/gn5/gn5i/sgn7i/vgn7i/vgn6i/gn7r/gn6v", "tencent": "PNV4/GT4/GN10Xp/GN7/GN7vi/PTX1/PNV4ne/GI3X/GN10X/GN8/GN6/GN6S", "aws": "p5/p4/p3/p2/dl1/trn1/imf2/inf1/vt1", "azure": "", "google": "a2/a3/g2"},
    {"hw": "pi1", "aliyun": "gn6i/gn7e/gn7i/gn7s/gn7/gn7r/gn6i/gn6e/gn6v/gn5/gn5i/sgn7i/vgn7i/vgn6i/gn7r/gn6v", "tencent": "PNV4/GT4/GN10Xp/GN7/GN7vi/PTX1/PNV4ne/GI3X/GN10X/GN8/GN6/GN6S", "aws": "p5/p4/p3/p2/dl1/trn1/imf2/inf1/vt1", "azure": "", "google": "a2/a3/g2"},
    {"hw": "p2vs", "aliyun": "ga1/gn6i/gn7e/gn7i/gn7s/gn7/gn7r/gn6i/gn6e/gn6v/gn5/gn5i/sgn7i/vgn7i/vgn6i/ebmgn7ix/gn6v/gn6e/ebmgn6v/ebmgn6ia", "tencent": "PNV4/GT4/GN10Xp/GN7/GN7vi/PTX1/PNV4ne/GI3X/GN10X/GN8/GN6/GN6S", "aws": "p5/p4/p3/p2/dl1/trn1/imf2/inf1/vt1", "azure": "", "google": "a2/a3/g2"},
    {"hw": "p2s", "aliyun": "ga1/gn6i/gn7e/gn7i/gn7s/gn7/gn7r/gn6i/gn6e/gn6v/gn5/gn5i/sgn7i/vgn7i/vgn6i/ebmgn7ix/gn6v/gn6e/ebmgn6v/ebmgn6ia", "tencent": "PNV4/GT4/GN10Xp/GN7/GN7vi/PTX1/PNV4ne/GI3X/GN10X/GN8/GN6/GN6S", "aws": "p5/p4/p3/p2/dl1/trn1/imf2/inf1/vt1", "azure": "", "google": "a2/a3/g2"},
    {"hw": "g6", "aliyun": "gn6i/gn7e/gn7i/gn7s/gn7/gn7r/gn6i/gn6e/gn6v/gn5/gn5i/sgn7i/vgn7i/vgn6i/ebmgn7ix/ebmgn6v/ebmgn6i/ebmgn6ia", "tencent": "GA3/GNV4v/GNV4/GN7vw/GI1/HCCG5v", "aws": "g5g/g5/g4dn/g4ad/g3/dl2q", "azure": "", "google": "g2"},
    {"hw": "g3", "aliyun": "gn4/ga1/gn6i/gn7e/gn7i/gn7s/gn7/gn7r/gn6i/gn6e/gn6v/gn5/gn5i/sgn7i/vgn7i/vgn6i/ebmgn7ix/gn6v/gn6e/ebmgn6v/ebmgn6ia", "tencent": "GA3/GNV4v/GNV4/GN7vw/GI1", "aws": "g5g/g5/g4dn/g4ad/g3/dl2q", "azure": "NV", "google": "g2"},
    {"hw": "fp1c/fp1", "aliyun": "f1/f2/f3", "tencent": "fx2", "aws": "f1", "azure": "", "google": ""},
    {"hw": "t6", "aliyun": "t6/t5/e", "tencent": "", "aws": "t3/t2/t4g/t3a", "azure": "B", "google": ""},
    {"hw": "Ai1", "aliyun": "", "tencent": "", "aws": "", "azure": "", "google": "a2/a3/g2"},
    {"hw": "c9", "aliyun": "g9i/g8i/g7se/g7/g7t/g7ne/g7nex/g6t/g6e/g6/g5ne/c7/c9i/c8i/c7re/c7se/c7nex/c7t/c6t/c6e/c6/ic5/u1/n1/n2", "tencent": "S9/S9e/S9pro/S8/S6/S5se/S4/S3/S2/C2/C3/C4/C5/C6/CN3", "aws": "m4/c7/m5/m5d/c5/c5d/c5n/m5n/m6i/c6i/c6id/m6in/c6in/m7i/c7i", "azure": "Dsv6/Dlsv6/DCevs5/DCedsv5/Dv5/Dsv5/Dlsv5/DCsv3/DCdsv3/Dv4/Dsv4/DSv2/Dsv3/Fsv2", "google": "c4/n4/c3d/c3"},
    {"hw": "m9", "aliyun": "r5/r6/r6e/r7/r7t/re7/r7p/r7se/r8i/r9i", "tencent": "M4/M3/M5/M6/M6ce/M6p/M8", "aws": "z1d/R5/R5b/R5n/R6i/R6in/R7i", "azure": "Dsv2/Ev3/Esv3/Ev4/Esv4/Ev5/Esv5/Ebdsv5/Ebsv5/Esv6", "google": "m1/m2/m3/m4"}
]

# 规格优先级配置
PRICE_FIRST_FLAVOR_PRIORITY = {"x1": 0, "x1e": 1, "s6": 2, "s3": 3, "s7": 4, "c3": 5, "c6": 6, "c7": 7, "c7h": 8}
PERFORMANCE_FIRST_FLAVOR_PRIORITY = {"c7": 0, "c7h": 1, "ac7": 2, "c6": 3, "x1e": 4, "c6s": 5, "c3": 6, "x1": 7, "s7": 8, "s6": 9, "s3": 10}
DEFAULT_FLAVOR_PRIORITY = 100
MIN_MEMORY_THRESHOLD_MB = 1536
MEMORY_THRESHOLD_FACTOR = 1.5


def get_compatible_hw_flavors(source_platform: str, source_flavor_family: str) -> List[str]:
    """获取源平台规格族对应的华为云兼容规格族列表"""
    compatible_flavors: Set[str] = set()
    for mapping in PLATFORM_FLAVOR_MAPPING:
        platform_flavors = mapping.get(source_platform, "")
        if platform_flavors and source_flavor_family in platform_flavors:
            compatible_flavors.add(mapping["hw"])
    return list(compatible_flavors)


def check_source_flavor(source_recommend_flavor_type: List[str], ecs_flavor) -> bool:
    """检查规格是否匹配推荐的规格类型"""
    return any(flavor_type in ecs_flavor.flavor_type for flavor_type in source_recommend_flavor_type)


def get_source_flavor_type(vendor: str, flavor: str) -> str:
    """获取源规格类型

    aliyun规格样例: ecs.c5.large
    tencent规格样例：S6.MEDIUM2
    aws规格样例：m7g.medium
    google规格样例：c3-standard-4
    """
    if not vendor or not flavor:
        return ""

    vendor_upper = vendor.upper()

    if vendor_upper == SourcePlatform.ALIYUN.value.upper():
        return get_aliyun_flavor_type(flavor)
    elif vendor_upper in (SourcePlatform.AWS.value.upper(), SourcePlatform.TENCENT.value.upper()):
        return get_aws_or_tencent_flavor_type(flavor)
    elif vendor_upper == SourcePlatform.GOOGLE.value.upper():
        return get_google_flavor_type(flavor)

    return flavor


def get_aliyun_flavor_type(flavor: str) -> str:
    """获取阿里云规格类型（ecs.c5.large -> c5）"""
    if not flavor:
        return ""
    if flavor.startswith("ecs."):
        flavor = flavor[4:]
    if "." in flavor:
        return flavor.split(".")[0]
    return flavor


def get_aws_or_tencent_flavor_type(flavor: str) -> str:
    """获取AWS/Tencent规格类型（m7g.medium -> m7g）"""
    if not flavor:
        return ""
    parts = re.split(r'[.\-]', flavor)
    return parts[0] if parts else flavor


def get_google_flavor_type(flavor: str) -> str:
    """获取Google规格类型（c3-standard-4 -> c3）"""
    if not flavor:
        return ""
    parts = re.split(r'[\-]', flavor)
    return parts[0] if parts else flavor


def get_recommend_flavor_type(source_flavor_type: str, vendor: str) -> List[str]:
    """根据源规格类型和供应商获取推荐的规格类型列表

    根据 PLATFORM_FLAVOR_MAPPING 查找源平台规格对应的华为云规格类型
    """
    if not source_flavor_type or not vendor:
        return []

    vendor_upper = vendor.upper()
    recommend_types = set()

    for mapping in PLATFORM_FLAVOR_MAPPING:
        platform_key = None
        if vendor_upper == SourcePlatform.ALIYUN.value.upper():
            platform_key = "aliyun"
        elif vendor_upper == SourcePlatform.AWS.value.upper():
            platform_key = "aws"
        elif vendor_upper == SourcePlatform.TENCENT.value.upper():
            platform_key = "tencent"
        elif vendor_upper == SourcePlatform.AZURE.value.upper():
            platform_key = "azure"
        elif vendor_upper == SourcePlatform.GOOGLE.value.upper():
            platform_key = "google"
        elif vendor_upper == SourcePlatform.HUAWEI_CLOUD.value.upper():
            platform_key = "hw"

        if platform_key:
            platform_flavors = mapping.get(platform_key, "")
            if platform_flavors and source_flavor_type in platform_flavors.split("/"):
                recommend_types.add(mapping["hw"])

    return list(recommend_types)


def raise_evaluate_exception(code: str):
    """抛出评估异常"""
    raise Exception(f"评估失败: {code}")


def calculate_cpu_threshold(source_cpu: int) -> int:
    """计算CPU阈值（下限为2，2的幂次向上取整后翻倍）"""
    if source_cpu <= 1:
        return 2
    if (source_cpu & (source_cpu - 1)) == 0:
        return source_cpu * 2
    return 1 << (source_cpu - 1).bit_length()


def calculate_memory_threshold(source_memory_mb: int) -> int:
    """计算内存阈值（源内存的1.5倍，最小1.5GB）"""
    threshold = int(source_memory_mb * MEMORY_THRESHOLD_FACTOR)
    return max(threshold, MIN_MEMORY_THRESHOLD_MB)


def get_flavor_priority(flavor_name: str, priority_mode: str) -> int:
    """获取规格优先级"""
    flavor_type = flavor_name.split(".")[0]
    if priority_mode == "price":
        return PRICE_FIRST_FLAVOR_PRIORITY.get(flavor_type, DEFAULT_FLAVOR_PRIORITY)
    if priority_mode == "performance":
        return PERFORMANCE_FIRST_FLAVOR_PRIORITY.get(flavor_type, DEFAULT_FLAVOR_PRIORITY)
    raise ValueError(f"不支持的优先级模式: {priority_mode}")


def filter_and_sort_flavors(
        flavors: List[Dict],
        cpu_threshold: int,
        memory_threshold: int,
        priority_mode: str = "performance",
        compatible_flavor_families: Optional[List[str]] = None
) -> List[Dict]:
    """过滤并排序符合条件的规格"""
    filtered_flavors = []
    for flavor in flavors:
        vcpus = int(flavor["vcpus"])
        ram = flavor["ram"]
        flavor_type = flavor["name"].split(".")[0]
        if vcpus < cpu_threshold or ram < memory_threshold:
            continue
        if compatible_flavor_families and flavor_type not in compatible_flavor_families:
            continue
        flavor["priority"] = get_flavor_priority(flavor["name"], priority_mode)
        filtered_flavors.append(flavor)
    return sorted(filtered_flavors, key=lambda x: (x["priority"], int(x["vcpus"]), x["ram"]))


def find_target_image(instance: ServerInstanceInput, all_images: List[Image], firmware: str = "bios") -> Tuple[Optional[Image], str]:
    """为目标主机操作系统查找最匹配的华为云镜像"""
    check_source_image(instance.os_info)
    os_type = instance.os_type
    if not os_type or os_type == "":
        os_type = get_os_type(instance.os_info)
    filtered_images = filter_images(all_images, os_type)

    # firmware = firmware.lower()
    # if firmware == "efi":
    #     firmware = HwFirmwareTypeEnum.UEFI.value
    #
    # firmware_filtered_images = [
    #     img for img in filtered_images
    #     if img.hw_firmware_type.value.lower() == firmware.lower()
    # ]
    firmware_filtered_images = None
    if not firmware_filtered_images:
        firmware_filtered_images = filtered_images

    platform_images = []
    for img in firmware_filtered_images:
        if img.platform:
            platform_lower = img.platform.lower()
            os_info_lower = instance.os_info.lower()
            if platform_lower in os_info_lower or os_info_lower in platform_lower:
                platform_images.append(img)

    if not platform_images:
        platform_images = firmware_filtered_images

    if not platform_images:
        return None, "none"

    recommend_image = get_recommend_image_by_similarity(platform_images, instance.os_info)

    if recommend_image:
        return recommend_image, "version_gte"

    return None, "no_match"


def process_instance(instance: ServerInstanceInput, all_flavors: List[Dict], all_images: List[Image], priority_mode: str, source_platform: str) -> InstanceAssessmentResult:
    """处理单个主机实例，返回评估结果"""
    source_recommend_flavor_type = filter_by_source_flavor_type(
        all_flavors, instance, instance.performance_type, source_platform
    )

    cpu_threshold = calculate_cpu_threshold(instance.cpu_cores)
    memory_mb = parse_memory_to_mb(instance.memory)
    memory_threshold = calculate_memory_threshold(memory_mb)

    sorted_flavors = filter_and_sort_flavors(
        all_flavors, cpu_threshold, memory_threshold, priority_mode, source_recommend_flavor_type
    )

    target_image, image_match_level = find_target_image(instance, all_images)

    if sorted_flavors:
        target_flavor = sorted_flavors[0]
        return InstanceAssessmentResult.from_success(
            resource_id=instance.resource_id,
            region=instance.region,
            original_type=instance.flavor_type,
            name=instance.instance_name,
            os_info=instance.os_info,
            source_flavor=instance.flavor_type,
            source_cpu=instance.cpu_cores,
            source_memory=instance.memory,
            recommended_flavor=target_flavor,
            recommended_image=target_image,
            image_match_level=image_match_level
        )

    return InstanceAssessmentResult.from_no_match(
        resource_id=instance.resource_id,
        region=instance.region,
        original_type=instance.flavor_type,
        name=instance.instance_name,
        os_info=instance.os_info,
        source_flavor=instance.flavor_type,
        source_cpu=instance.cpu_cores,
        source_memory=instance.memory,
        recommended_image=target_image,
        image_match_level=image_match_level
    )


def filter_by_source_flavor_type(
    detail_ecs_flavors: list,
    item,
    performance_type: Optional[str] = None,
    vendor: str = ""
) -> list:
    """根据源规格类型过滤目标规格列表"""
    source_recommend_flavor_type = []
    vendor = vendor.lower()

    if vendor in HUAWEI:
        source_recommend_flavor_type = []
        source_flavor_split = item.flavor_type.split(".")
        source_recommend_flavor_type.append(source_flavor_split[0])

        if performance_type:
            if performance_type.upper() == "NORMAL":
                source_recommend_flavor_type.append("x1")
            elif performance_type.upper() in ("COMPUTINGV3", "HIGHMEM"):
                source_recommend_flavor_type.append("x1e")

    elif vendor.upper() in OTHER or vendor.upper() in VMWARE:
        source_recommend_flavor_type = []
        cpu_cores = item.cpu_cores
        mem = item.memory
        cpu_mem_ratio = cpu_cores / mem if mem > 0 else 0

        if cpu_mem_ratio >= 0.25:
            if cpu_cores <= 8:
                flavor_list_key = "vmware_flavor_type_list_ratio_h25_when_cpu_l8"
            else:
                flavor_list_key = "vmware_flavor_type_list_ratio_h25_when_cpu_h8"
        elif cpu_mem_ratio >= 0.125:
            flavor_list_key = "vmware_flavor_type_list_ratio_between_125_and_25"
        else:
            flavor_list_key = "vmware_flavor_type_list_ratio_l125"

        source_recommend_flavor_type.extend(SPEC_ASSESS_OPERATION_LIST[flavor_list_key])

    else:
        source_flavor_type = get_source_flavor_type(vendor, item.flavor_type)
        if not source_flavor_type:
            return source_recommend_flavor_type

        source_recommend_flavor_type_by_rule = get_recommend_flavor_type(source_flavor_type, vendor)
        source_recommend_flavor_type = list(source_recommend_flavor_type_by_rule)

    return source_recommend_flavor_type


# ============================================================
# 华为云API调用
# ============================================================

def fetch_huawei_cloud_flavors(region: str, ak: str, sk: str) -> List[Dict]:
    """获取华为云指定区域的ECS规格列表"""
    try:
        credentials = BasicCredentials(ak, sk)
        client = EcsClient.new_builder() \
            .with_credentials(credentials) \
            .with_region(EcsRegion.value_of(region)) \
            .with_http_config(config)\
            .build()

        all_flavors = []
        next_marker = None
        page_number = 1

        while True:
            try:
                request = ListFlavorsRequest()
                request.limit = 1000
                if next_marker:
                    request.marker = next_marker

                response = client.list_flavors(request)
                raw_response = json.loads(response.raw_content.decode("utf-8"))

                current_flavors = raw_response.get("flavors", [])
                all_flavors.extend(current_flavors)

                page_info = raw_response.get("page_info", {})
                next_marker = page_info.get("next_marker")

                if not next_marker:
                    break

                page_number += 1

            except exceptions.ClientRequestException as e:
                print(f"查询规格时发生错误: {e.error_msg}")
                raise
        return all_flavors
    except Exception as e:
        print(f"错误：{str(e)}")
        return []


def fetch_huawei_cloud_images(ak: str, sk: str, region: str) -> List[Image]:
    """获取华为云指定区域的镜像列表"""
    try:
        credentials = BasicCredentials(ak, sk)
        client = ImsClient.new_builder() \
            .with_credentials(credentials) \
            .with_region(ImsRegion.value_of(region)) \
            .with_http_config(config) \
            .build()

        images = []
        next_marker = None
        page = 1
        while True:
            request = ListImagesRequest()
            request.limit = 1000
            if next_marker:
                request.marker = next_marker

            response = client.list_images(request)
            raw_response = json.loads(response.raw_content.decode("utf-8"))

            image_list = raw_response.get("images", [])
            if not image_list:
                break

            for img in image_list:
                name = img.get("name", "")
                version = extract_version_from_name(name)

                images.append(Image(
                    imageId=img.get("id", ""),
                    name=name,
                    version=version,
                    osType=img.get("__os_type", "").lower()
                ))

            page_info = raw_response.get("page_info", {})
            next_marker = page_info.get("next_marker")

            if not next_marker:
                break
            page += 1

        return images

    except exceptions.ClientRequestException as e:
        print(f"查询镜像时发生错误: {e.error_msg}")
        return []


# ============================================================
# 主评估函数（API入口）
# ============================================================

def assess_server_specs(
    ecs_instances: List[Dict],
    region: str,
    ak: str,
    sk: str,
    source_platform: str = "aliyun",
    priority_mode: str = "price"
) -> AssessmentResponse:
    """
    主机规格和镜像评估主函数

    Args:
        ecs_instances: 主机资源信息列表（List[Dict]），每个字典应包含：
            - 资源ID: 实例ID
            - 地域: 地域信息
            - 规格/实例类型: 原始规格
            - 实例名称: 名称
            - 操作系统信息: 操作系统描述
            - CPU核心数: CPU数量
            - 内存: 内存大小（如"4GB"、"4096MB"）
        region: 华为云目标区域
        ak: 华为云Access Key
        sk: 华为云Secret Key
        source_platform: 源平台类型，默认"aliyun"
        priority_mode: 优先级模式，"price"或"performance"

    Returns:
        AssessmentResponse，包含：
            - request_id: 请求ID
            - timestamp: 评估时间
            - region: 目标区域
            - results: 单个实例评估结果列表
            - summary: 统计摘要
    """
    print(f"开始评估 {len(ecs_instances)} 个主机实例...")
    print(f"目标区域: {region}, 优先级模式: {'性能优先' if priority_mode == 'performance' else '价格优先'}")

    # 获取华为云规格列表
    print(f"\n正在获取华为云{region}区域的ECS规格列表...")
    all_flavors = fetch_huawei_cloud_flavors(region, ak, sk)
    print(f"获取到 {len(all_flavors)} 个可用规格")

    # 获取华为云镜像列表
    print(f"\n正在获取华为云{region}区域的镜像列表...")
    all_images = fetch_huawei_cloud_images(ak, sk, region)
    print(f"获取到 {len(all_images)} 个镜像")

    # 批量处理
    print(f"\n开始批量处理实例...")
    results: List[InstanceAssessmentResult] = []

    for i, instance in enumerate(ecs_instances, 1):
        instance_input = ServerInstanceInput.from_dict(instance)
        print(f"处理中: {i}/{len(ecs_instances)} - 实例ID: {instance_input.resource_id}")

        try:
            result = process_instance(instance_input, all_flavors, all_images, priority_mode, source_platform)
            results.append(result)

        except Exception as e:
            print(f"  错误：处理实例失败 - {str(e)}")
            result = InstanceAssessmentResult.from_failed(
                    resource_id=instance_input.resource_id,
                    region=instance_input.region,
                    original_type=instance_input.flavor_type,
                    name=instance_input.instance_name,
                    os_info=instance_input.os_info,
                    source_flavor=instance_input.flavor_type,
                    source_cpu=instance_input.cpu_cores,
                    source_memory=instance_input.memory,
                    error_message=str(e)
                )
            results.append(result)
        print(f"{result.to_dict()}")
    # 创建响应对象
    response = AssessmentResponse(
        region=region,
        results=results
    )

    print("\n" + "=" * 80)
    print("评估完成！统计摘要：")
    print(f"  总计: {response.summary.total} 个")
    print(f"  成功: {response.summary.success} 个")
    print(f"  无匹配: {response.summary.no_match} 个")
    print(f"  处理失败: {response.summary.failed} 个")
    print("=" * 80)

    return response


def assess_server_specs_with_credential(
    ecs_instances: List[Dict],
    region: str,
    credential_name: str,
    source_platform: str = "aliyun",
    priority_mode: str = "price"
) -> AssessmentResponse:
    """
    使用RDA凭证进行主机规格评估

    Args:
        ecs_instances: 主机资源信息列表
        region: 华为云目标区域
        credential_name: RDA中的凭证名称
        source_platform: 源平台类型
        priority_mode: 优先级模式

    Returns:
        AssessmentResponse: 评估响应对象
    """
    if not HAS_RDA_CLIENT:
        raise ImportError("RDA客户端未安装或不可用")

    client = RdaClient()
    service = CredentialService(client)
    ak_sk = service.get_ak_sk_by_name(credential_name)

    if 'error' in ak_sk:
        raise ValueError(f"获取凭证失败: {ak_sk['error']}")

    return assess_server_specs(
        ecs_instances=ecs_instances,
        region=region,
        ak=ak_sk['ak'],
        sk=ak_sk['sk'],
        source_platform=source_platform,
        priority_mode=priority_mode
    )


# ============================================================
# 兼容性包装函数（支持原文件输入方式）
# ============================================================

def read_aliyun_resources(json_file_path: str) -> List[Dict]:
    """从JSON文件读取主机资源（兼容原脚本）"""
    try:
        with open(json_file_path, "r", encoding="utf-8-sig") as f:
            data = json.load(f)
        ecs_instances = data.get("resources", {}).get("主机", [])
        if not ecs_instances:
            raise ValueError("JSON文件中未找到ECS实例信息")
        return ecs_instances
    except FileNotFoundError:
        raise FileNotFoundError(f"文件不存在: {json_file_path}")
    except json.JSONDecodeError:
        raise ValueError(f"JSON文件格式错误: {json_file_path}")


# ============================================================
# 主入口（CLI模式，保留原脚本兼容性）
# ============================================================

def main():
    """CLI主入口（保留原脚本用法兼容）"""
    import argparse

    parser = argparse.ArgumentParser(description="华为云ECS规格批量推荐工具")
    parser.add_argument("json_file", help="阿里云导出的JSON资源清单文件路径")
    parser.add_argument('credential_name', help='RDA-LITE凭证名称')
    parser.add_argument("region", help="华为云目标区域")
    parser.add_argument("source_platform", default="aliyun", choices=["aliyun", "huawei-cloud"])
    parser.add_argument("--priority_mode", default="price", choices=["performance", "price"])
    parser.add_argument("--output_dir", default=r"C:\DiscoveryData\SpecRecommend", help="保存文件目录")
    args = parser.parse_args()

    # 读取资源文件
    print(f"正在读取阿里云资源清单: {args.json_file}")
    try:
        ecs_instances = read_aliyun_resources(args.json_file)
        print(f"成功读取到 {len(ecs_instances)} 个ECS实例")
    except Exception as e:
        print(f"错误：{str(e)}")
        return

    # 调用评估函数
    result = assess_server_specs_with_credential(
        ecs_instances=ecs_instances,
        region=args.region,
        credential_name=args.credential_name,
        source_platform=args.source_platform,
        priority_mode=args.priority_mode
    )

    # 保存结果
    os.makedirs(args.output_dir, exist_ok=True)
    current_time = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    output_file = os.path.join(args.output_dir, f"{args.source_platform}_server_spec_assessment_{current_time}.json")

    with open(output_file, "w", encoding="utf-8") as f:
        json.dump(result.to_dict(), f, ensure_ascii=False, indent=2)

    print(f"\n结果已保存到: {output_file}")


if __name__ == "__main__":
    main()
